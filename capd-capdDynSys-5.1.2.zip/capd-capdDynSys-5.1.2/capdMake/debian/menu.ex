?package(capd):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="capd" command="/usr/bin/capd"
