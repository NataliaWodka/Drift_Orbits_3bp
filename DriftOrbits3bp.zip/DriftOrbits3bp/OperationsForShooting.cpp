#include "OperationsForShooting.h"


/// double

DVector PullOut(DVector q, int m)
{
	DVector x(4);
	int j=0;
	for(int i=1+4*(m-1);i<1+4*m;i++)
	{
		x[j]=q[i];
		j++;
	}
	return x;
}

void Insert(DVector &p, DVector x, int m)
{
	int j=0;
	for(int i=4*(m-1);i<4*m;i++)
	{
		p[i]=x[j];
		j++;
	}
}

void PutFirst(DVector v, DMatrix &DF)
{
	for(int i=0;i<4;i++)
		DF[i][0]=v[i];
}

void PutLast(DVector v, DMatrix &DF, int m)
{
	for(int i=1+4*(m-1);i<1+4*m;i++)
		DF[4*m][i]=v[i-(1+4*(m-1))];
}

void PutSecondLast(DVector v, DMatrix &DF, int m)
{
	for(int i=1+4*(m-1);i<1+4*m;i++)
		DF[4*m+1][i]=v[i-(1+4*(m-1))];
}

void InsertLastColumn(DVector v, DMatrix &DF, int m)
{
	int N=DF.numberOfColumns();
	for(int i=0;i<4;i++) DF[4*m+i][N-1]=v[i];
}

void PutId(DMatrix &DF, int n)
{
	for(int k=1;k<1+4*n;k++)
		DF[k-1][k]=-1;
}

void PutIn(DMatrix Df, DMatrix &DF, int m)
{
	int j=0;
	for(int k=4*m;k<4*(m+1);k++)
	{
		int i=0;
		for(int l=1+4*(m-1);l<1+4*m;l++)
		{
			DF[k][l]=Df[j][i];
			i++;
		}
		j++;
	}	
}

DVector Column(DMatrix A, int k)
{
	DVector x(A.numberOfRows());
	for(int i=0;i<A.numberOfRows();i++)
		x[i]=A[i][k];
	return x;
}

DVector Row(DMatrix A, int k)
{
	DVector x(A.numberOfColumns());
	for(int i=0;i<A.numberOfColumns();i++)
		x[i]=A[k][i];
	return x;
}

// interval

///////////////////////////////////////////////

IVector PullOut(IVector q, int m)
{
    IVector x(4);
    int j=0;
    for(int i=1+4*(m-1);i<1+4*m;i++)
    {
        x[j]=q[i];
        j++;
    }
    return x;
}

void Insert(IVector &p, IVector x, int m)
{
    int j=0;
    for(int i=4*(m-1);i<4*m;i++)
    {
        p[i]=x[j];
        j++;
    }
}

void PutFirst(IVector v, IMatrix &DF)
{
    for(int i=0;i<4;i++)
        DF[i][0]=v[i];
}

void PutLast(IVector v, IMatrix &DF, int m)
{
    for(int i=1+4*(m-1);i<1+4*m;i++)
        DF[4*m][i]=v[i-(1+4*(m-1))];
}

void PutSecondLast(IVector v, IMatrix &DF, int m)
{
    for(int i=1+4*(m-1);i<1+4*m;i++)
        DF[4*m+1][i]=v[i-(1+4*(m-1))];
}

void InsertLastColumn(IVector v, IMatrix &DF, int m)
{
    int N=DF.numberOfColumns();
    for(int i=0;i<4;i++) DF[4*m+i][N-1]=v[i];
}

void PutId(IMatrix &DF, int n)
{
    for(int k=1;k<1+4*n;k++)
        DF[k-1][k]=-1;
}

void PutIn(IMatrix Df, IMatrix &DF, int m)
{
    int j=0;
    for(int k=4*m;k<4*(m+1);k++)
    {
        int i=0;
        for(int l=1+4*(m-1);l<1+4*m;l++)
        {
            DF[k][l]=Df[j][i];
            i++;
        }
        j++;
    }
}

IVector Column(IMatrix A, int k)
{
    IVector x(A.numberOfRows());
    for(int i=0;i<A.numberOfRows();i++)
        x[i]=A[i][k];
    return x;
}

IVector Row(IMatrix A, int k)
{
    IVector x(A.numberOfColumns());
    for(int i=0;i<A.numberOfColumns();i++)
        x[i]=A[k][i];
    return x;
}



