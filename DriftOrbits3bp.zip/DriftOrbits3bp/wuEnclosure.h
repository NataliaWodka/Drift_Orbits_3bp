#ifndef wuEnclosure_h
#define wuEnclosure_h

#include "capd/capdlib.h"
using namespace capd;
using namespace std;

// Here we establish the existence of unstable fibers on the unstable manifold of a Lyapunov orbit.
// The fibers are based on a sequence of points p[i] along the Lyapunov orbit.
// Each fiber is contained in a cone of the form
//     p[i]+range*A[i]*Cone[i]
// where Cone[i] is a set of the form
//     Cone[i]={(x,y) : x\in [-1,1] and y\in x*(Cone[1] \times Cone[2] \times Cone[3])}
// in our computer program such cone is represented as an IVector
//     Cone[i]=(1,Cone[1],Cone[2],Cone[3])
// The function establishes the existence of the fibers, as well as computes the sequence of cones. 
// The first cone attached at p[0] is chosen as
//     Cone[0]=(1,[-L,L],[-L,L],[-L,L])
// The reminder of the cones Cone[i] are computed in the routine.
// The function also computes the interval "m". This coefficient satisfies:
//    ||p[i+1]-f[i](q)|| > m*||p[i]-q||
// for every point q which lies on a fiber of with the base p[i].
// The function also computes the interval "mbar". This coefficient satisfies:
//    ||p[i+1]-f[i](q)|| <= mbar*||p[i]-q||
// for every point q which lies on a fiber of with the base p[i].
bool validateWuEnclosure(vector<IVector> p,interval t,vector<IMatrix> &A,interval &L,interval range,ITimeMap &Phi,int d,interval &m,interval &mbar,IPoincareMap &P,vector<IVector> &Cone);

////////////////////
// This function establishes that the unstable fiber at a point
//  (x,theta)
// where x=p[0] is a point on the Lyapunov orbit and theta is an arbitrary angle (i.e. time in extended phase space),
// is contained in
//  W^u_(x,theta) \in (p[0],theta)+diag(A[0],1)*Cone
// where 
//  Cone=(1,[-L,L],[-L,L],[-L,L],[-M,M])   
bool validateFiberInExtendedPhaseSpace(vector<IVector> p,interval t,vector<IMatrix> A,interval L,interval M,interval range,ITimeMap &Phi,IPoincareMap &P,int d);
#endif