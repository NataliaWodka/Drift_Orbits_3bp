#ifndef MelnikovComputation_h
#define MelnikovComputation_h

#include "capd/capdlib.h"
using namespace capd;
using namespace std;

#include "utils.h"

inline interval scatteringMap(interval lambda,interval range,interval M,interval LyapPeriod,interval homoclinicTime)
{
	return lambda + 2*interval(-1,1)*M*range + homoclinicTime - 5*LyapPeriod;
}

// This function computes m(z) from the paper.
int find_m_iterates(interval theta,interval range,interval M,interval LyapPeriod,interval homoclinicTime,interval strip);

// This function establishes that the inner dynamics starting from angle theta will 
// enter after some number of iterates in the given strip.
void checkStripTransition(interval theta,interval LyapPeriod,interval strip);


interval LgBound(const vector<IVector> &q,const vector<IMatrix> &A,const vector<IVector> &cone, const interval &range, const interval &t, const interval &mbar,
										ICnTimeMap &Phi,ICnPoincareMap &P,IMap &H);
										
interval gI(vector<IVector> p,interval &theta,interval t,ITimeMap &Phi,IPoincareMap &P,IMap &H);
interval gI(vector<IVector> p,vector<IMatrix> A, vector<IVector> Cone,interval &Domain,interval m,interval &theta,interval t,ITimeMap &Phi,IPoincareMap &P,IMap &H);

#endif