#ifndef eigenvector_h
#define eigenvector_h
#include "capd/capdlib.h"
using namespace capd;
using namespace capd::alglib;
using namespace capd::matrixAlgorithms;
using namespace std;


//////////////////////////////////
// Function: containsEigenvalueAndEigenvector(()
// 
// Purpose: This function verifies that 
//      A*V = Lambda*V
// In other words, we establish that 
//      V
// is an eigenvector of the matrix A with the eigenvalue
//      Lambda
// The function returns:
//      1   - if Lambda contains a true eigenvalue of A and V contains its associated eigenvector,
//      0   - if the method does not ensure the enclosure. (Such enclosure is not rulled out, 
//            but is not proved by the method) 
// Notes: 
// - This function will succeed only in the setting where V and lambda are indeed real,
//   otherwise the function will return an error and terminate the program.
// - From this method it follows that there is no other eigenvalue in Lambda and no other
//   eigenvector in V.
bool containsEigenvalueAndEigenvector(const IMatrix &A,const interval &Lambda,const IVector &V);

//////////////////////////////////
// Function: containsEigenvalueAndEigenvector()
// 
// Purpose: This function verifies that 
//      A*(Vre + i*Vim) = (rho + i*omega)*(Vre + i*Vim)
// In other words, we establish that 
//      V = Vre + i*Vim 
// is an eigenvector of the matrix A with the eigenvalue
//      Lambda = rho + i*omega
// The function returns:
//      1   - if Lambda contains a true eigenvalue of A and V contains its associated eigenvector,
//      0   - if the method does not ensure the enclosure. (Such enclosure is not rulled out, 
//            but is not proved by the method) 
// Note: 
// - From this method it follows that there is no other eigenvalue in Lambda and no other
//   eigenvector in V.
bool containsEigenvalueAndEigenvector(const IMatrix &A,const interval &rho,const interval &omega,const IVector &Vre,const IVector &Vim);

#endif