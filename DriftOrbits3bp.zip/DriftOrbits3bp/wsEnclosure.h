#ifndef wsEnclosure_h
#define wsEnclosure_h

#include "capd/capdlib.h"
using namespace capd;
using namespace std;

// Here we establish the existence of stable fibers on the stable manifold of a Lyapunov orbit.
// The fibers are based on a sequence of points p[i] along the Lyapunov orbit.
// Each fiber is contained in a cone of the form
//     p[i]+range*A[i]*Cone[i]
// where Cone[i] is a set of the form
//     Cone[i]={(x,y) : x\in [-1,1] and y\in x*(Cone[1] \times Cone[2] \times Cone[3])}
// in our computer program such cone is represented as an IVector
//     Cone[i]=(1,Cone[1],Cone[2],Cone[3])
// The fibers are computed from the symmetry property of the PRC3BP. Once we validate the points p[i] along the homoclinic,
// and the unstable fibers based at these points, the stable fibers follow from symmetry:
// If 
//    p[i]+range*A[i]*Cone[i]
// encloses the unstable fiber based at p[i] then
//    S*p[i]+range*S*A[i]*Cone[i]
// encloses the stable fiber based at S*p[i]. 
// We make use of the fact that the points p[i] are on an S-symmetric periodic orbit. This means that
//    S*p[i]=p[k-i]    for i=1,...,k-1
// where our points are:
//    p[0],p[1],...,p[k-1]
// with p[0] being self S-symmetric p[0]=S*p[0]. This means that we do not need to make any modifications to the points p[i].
// As a result of executing validateWsEnclosure() we obtain a sequence of sets:
//    Ws[i]:=p[i]+range*A[i]*Cone[i] 
// (where A, Cone have been recomputed by the function) so that the stable fibers at p[i] are contained in Ws[i]. Moreover, the fibers from Ws[i] map into Ws[i+1], and the fiber Ws[n-1] maps into Ws[0].
void validateWsEnclosure(vector<IMatrix> &A,vector<IVector> &Cone);

#endif