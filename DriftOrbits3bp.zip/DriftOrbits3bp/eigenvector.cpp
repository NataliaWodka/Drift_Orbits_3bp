#include "eigenvector.h"

// =================== Auxhiliary functions =============

void swapColumns(IMatrix &A,int i)
{
    int n=A.numberOfRows();
    interval a;
    for(int k=0;k<n;k++)
    {
        a=A[k][0];
        A[k][0]=A[k][i];
        A[k][i]=a;
    }
}

void swapRows(IMatrix &A,int i)
{
    int n=A.numberOfColumns();
    interval a;
    for(int k=0;k<n;k++)
    {
        a=A[0][k];
        A[0][k]=A[i][k];
        A[i][k]=a;
    }
}

void swapCoordinates(IMatrix &A,int i)
{
    swapRows(A,i);
    swapColumns(A,i);
}

void swapCoordinates(IVector &x,int i)
{
    interval a;
    a=x[0];
    x[0]=x[i];
    x[i]=a;
}

int maxCoordinate(const IVector &x)
{
    int n=x.dimension();
    int k=0;
    interval max=(x[0]*x[0]).right();
    for(int i=1;i<n;i++)
    {
        if(max<(x[i]*x[i]).right())
        {
            max=(x[i]*x[i]).right();
            k=i;
        }
    }
    return k;
}

// =============== functions for the real case ==============

// Let v be the eigenvector. Here x=(lambda,v~). 
// The v0 (which is the first coordinate of the eigenvector) is treated as a parameter
IVector f(const IMatrix &A,const IVector &x,const interval &v0)
{
	IVector w=x;
	w[0]=v0;
	interval lambda=x[0];
	return A*w-lambda*w;
}

// Let v be the eigenvector. Here x=(lambda,v~). 
// The v0 (which is the first coordinate of the eigenvector) is treated as a parameter
IMatrix Df(const IMatrix &A,const IVector &x,const interval &v0)
{
	IMatrix df=A;
	df[0][0]=-v0;
	for(int i=1;i<A.numberOfRows();i++) 
	{
		df[i][0]=-x[i];
		df[i][i]=df[i][i]-x[0];
	}
	return df;
}

IVector N(const IMatrix &A,const IVector &x,const interval &v0)
{
	return midVector(x) - gauss(Df(A,x,v0),f(A,midVector(x),v0));
}

// here we treat V[0] as the parameter:
bool containsEigenvalueAndEigenvector1(const IMatrix &A,const interval &Lambda,const IVector &V)
{
	IVector x=V;
	x[0]=Lambda;
	IVector y=N(A,x,V[0]);
    if(subsetInterior(y,x)==0) return 0;
    return 1;
}

bool containsEigenvalueAndEigenvector(const IMatrix &A,const interval &Lambda,const IVector &V)
{
	IVector v=V;
    int k=maxCoordinate(v);
    v[k]=v[k].mid(); // below we check that v contains an eigenvector. If so, then so will V.
    swapCoordinates(v,k);
    
    IMatrix B=A;
    swapCoordinates(B,k);
    
    return containsEigenvalueAndEigenvector1(B,Lambda,v);
}

// =============== functions for the complex case ==============

IVector glue(const IVector &x,const IVector &y)
{
    int n=x.dimension();
    int m=y.dimension();
    IVector z(n+m);
    for(int i=0;i<n;i++) z[i]=x[i];
    for(int i=0;i<m;i++) z[n+i]=y[i];
    return z;
}

void project(const IVector &x,IVector &x1,IVector &x2)
{
    int n=x1.dimension();
    int m=x2.dimension();
    for(int i=0;i<n;i++) x1[i]=x[i];
    for(int i=0;i<m;i++) x2[i]=x[n+i];
}

// Let v = vre + i*vim be the eigenvector.
// Here x = (rho,vre~) + i*(omega,vim~).
// The v0re and v0im (which are the first coordinates of the eigenvector) are treated as parameters.
IVector F(const IMatrix &A, const IVector &x, const interval &v0re, const interval &v0im)
{
    int n=x.dimension()/2;
    IVector w1(n),w2(n);
    project(x,w1,w2);
    
    interval rho=w1[0];
    interval omega=w2[0];
    
    w1[0]=v0re;
    w2[0]=v0im;
    
    IVector x1 = A*w1 - rho*w1 + omega*w2;
    IVector x2 = A*w2 - rho*w2 - omega*w1;
    return glue(x1,x2);
}

// Let v = vre + i*vim be the eigenvector.
// Here x = (rho,vre~) + i*(omega,vim~).
// The v0re and v0im (which are the first coordinates of the eigenvector) are treated as parameters.
IMatrix DF(const IMatrix &A,const IVector &x,const interval &v0re, const interval &v0im)
{
    int n=x.dimension()/2;
    IMatrix B(2*n,2*n);
    
    interval rho=x[0];
    interval omega=x[n];
    
    B[0][0]=-v0re;
    for(int k=1;k<n;k++) B[0][k]=A[0][k];
    B[0][n]=v0im;
    
    for(int i=1;i<n;i++)
    {
        B[i][0]=-x[i];
        for(int k=1;k<n;k++)
        {
            B[i][k]=A[i][k];
            if(i==k) B[i][k]=B[i][k]-rho;
        }
        B[i][n]=-x[n+i];
        B[i][n+i] = omega;
    }
    
    B[n][0]=-v0re;
    B[n][n]=-v0im;
    for(int k=1;k<n;k++) B[n][n+k]=A[0][k];
    
    for(int i=1;i<n;i++)
    {
        B[n+i][0]=-x[n+i];
        B[n+i][i]=-omega;
        B[n+i][n]=-x[i];
        for(int k=1;k<n;k++)
        {
            B[n+i][n+k] = A[i][k];
            if(i==k) B[n+i][n+k] = B[n+i][n+k]-rho;
        }
    }
    return B;
}

IVector Ncomplex(const IMatrix &A,const IVector &x,const interval &v0re, const interval &v0im)
{
    return midVector(x) - gauss(DF(A,x,v0re,v0im),F(A,midVector(x),v0re,v0im));
}

bool containsEigenvalueAndEigenvector1(const IMatrix &A,const interval &rho,const interval &omega,const IVector &Vre,const IVector &Vim)
{
    IVector x1=Vre;
    IVector x2=Vim;
    x1[0]=rho;
    x2[0]=omega;
    
    IVector x=glue(x1,x2);
    IVector y=Ncomplex(A,x,Vre[0],Vim[0]);
    if(subsetInterior(y,x)==0) return 0;
    return 1;
}

bool containsEigenvalueAndEigenvector(const IMatrix &A,const interval &rho,const interval &omega,
		const IVector &Vre,const IVector &Vim)
{
	IVector vre=Vre;
	IVector vim=Vim;
    int k=maxCoordinate(vre);
	vre[k]=vre[k].mid();
	vim[k]=vim[k].mid();
	// if v = vre+ivim contains an eigenvector, so will V=Vre+i*Vim
    swapCoordinates(vre,k);
    swapCoordinates(vim,k);
    IMatrix B=A;
    swapCoordinates(B,k);
    return containsEigenvalueAndEigenvector1(B,rho,omega,vre,vim);
}
