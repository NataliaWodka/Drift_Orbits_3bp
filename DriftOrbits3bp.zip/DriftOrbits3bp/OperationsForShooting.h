#ifndef OperationsForShooting_h
#define OperationsForShooting_h
#include "capd/capdlib.h"
using namespace capd;
using namespace std;
 
// double
DVector PullOut(DVector q, int m);
void Insert(DVector &p, DVector x, int m);
void PutFirst(DVector v, DMatrix &DF);
void PutId(DMatrix &DF, int n);
void PutLast(DVector v, DMatrix &DF, int m);
void PutIn(DMatrix Df, DMatrix &DF, int m);
void PutSecondLast(DVector v, DMatrix &DF, int m);
void InsertLastColumn(DVector v, DMatrix &DF, int m);
DVector Column(DMatrix A, int k);
DVector Row(DMatrix A, int k);

// interval
IVector PullOut(IVector q, int m);
void Insert(IVector &p, IVector x, int m);
void PutFirst(IVector v, IMatrix &DF);
void PutId(IMatrix &DF, int n);
void PutLast(IVector v, IMatrix &DF, int m);
void PutIn(IMatrix Df, IMatrix &DF, int m);
void PutSecondLast(IVector v, IMatrix &DF, int m);
void InsertLastColumn(IVector v, IMatrix &DF, int m);
IVector Column(IMatrix A, int k);
IVector Row(IMatrix A, int k);

#endif
