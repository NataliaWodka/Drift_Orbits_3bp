#ifndef plots_h
#define plots_h
#include <iostream>
#include "capd/capdlib.h"
using namespace capd;
using namespace std;


// This function was used to produce the plot of the homoclinic orbit in the paper. It is not a part of the computer assisted proof.
void plotHomoclinic(const vector<IVector> &p,interval h);

// This function was used to produce the plot of the energy changes. It is not a part of the computer assisted proof.
void plotEnergyChange(vector<IVector> p,interval t,ITimeMap &Phi,IPoincareMap &P,IMap &H);

#endif