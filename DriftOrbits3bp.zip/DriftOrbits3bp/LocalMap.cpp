#include "LocalMap.h"
#include "utils.h"
DLocalMap::DLocalMap(DVector a_,DVector b_,DMatrix A_,DMatrix B_, DTimeMap &Phi_,double T_)
{
	Phi=&Phi_;
	A=A_;
	B=B_;
	a=a_;
	b=b_;
	T=T_;
}

DVector DLocalMap::image(const DVector &x) const
{
	DVector y=a+A*x;
	return B*((*Phi)(T,y)-b);
}

DVector DLocalMap::image(const DVector &x, DMatrix &Df) const
{
	DMatrix DPhi;
	DVector y=a+A*x;
	y=B*((*Phi)(T,y,DPhi)-b);
	Df=B*DPhi*A;
	return y;
}

DMatrix DLocalMap::derivative(const DVector &x) const
{
	DMatrix Df;
	image(x,Df);
	return Df;
}

vector<DLocalMap> LocalMap(const vector<DVector> &x,const vector<DMatrix> &A,DTimeMap &Phi,double T)
{
	int k=x.size()-1;
	vector<DLocalMap> f(k);
	for(int i=0;i<k;i++) f[i]=DLocalMap(x[i],x[i+1],A[i],gaussInverseMatrix(A[i+1]),Phi,T);
	return f;
}

// // // // interval versions // // // //

IVector PropagateCone(const IMatrix &DF,const IVector &C)
{
    IVector V=DF*C;
	//cout << DF << endl;
    
    int d=V.dimension();
    if(! (abs(V[0])>0)) {cout << "There is a problem with cone propagation. Aborting program. "; abort(); }
    if(V[0]<0) V=-V;
    
    for(int i=1;i<d;i++) V[i]=(V[i])/(V[0].left());
    V[0]=1.0;
    return V;
}

ILocalMap::ILocalMap(IVector a_,IVector b_,IMatrix A_,IMatrix B_, ITimeMap &Phi_,interval T_)
{
	Phi=&Phi_;
	P=NULL;
	A=A_;
	B=B_;
	a=a_;
	b=b_;
	T=T_;
}

ILocalMap::ILocalMap(IVector a_, IVector b_, IMatrix A_, IMatrix B_, IPoincareMap &P_)
{
	Phi=NULL;
	P=&P_;
	A=A_;
	B=B_;
	a=a_;
	b=b_;
	T=interval(0.0);
}

IVector ILocalMap::image(const IVector &x) const
{
	IMatrix D;
	return image(x,D);
}

IVector ILocalMap::image(const IVector &x,IMatrix &Df) const
{
	IVector x0=midVector(x);
	IVector R=x-x0;
	
	//computation of Df:
	C1Rect2Set Q(a+A*x0,A,R);
	IMatrix DPhi; 
	if(P==NULL) (*Phi)(T,Q,DPhi);
	if(Phi==NULL)
	{
		IVector y=(*P)(Q,DPhi);
		DPhi=P->computeDP(y,DPhi);
	}
    
	Df=B*DPhi*A;
	
	// computation of f(x0):
	IVector z(x.dimension());
	C0Rect2Set q(a+A*x0,A,z);
	IVector y0;
	if(P==NULL)   y0 = (*Phi)(T,q);
	if(Phi==NULL) y0 = (*P)(q);
	
	IVector fx0 = B*(y0-b);
	return fx0 + Df*R;
}

IMatrix ILocalMap::derivative(const IVector &x) const
{
	IMatrix Df;
	image(x,Df);
	return Df;
}

vector<ILocalMap> LocalMap(const vector<IVector> &x,const vector<IMatrix> &A,ITimeMap &Phi,interval T)
{
	int k=x.size()-1;
	vector<ILocalMap> f(k);
	for(int i=0;i<k;i++) f[i]=ILocalMap(x[i],x[i+1],A[i],gaussInverseMatrix(A[i+1]),Phi,T);
	return f;
}

vector<ILocalMap> LocalMap(const vector<IVector> &x, const vector<IMatrix> &A, ITimeMap &Phi, interval T,IPoincareMap &P)
{
	int k=x.size()-1;
	vector<ILocalMap> f(k);
	for(int i=0;i<k-1;i++) f[i]=ILocalMap(x[i],x[i+1],A[i],gaussInverseMatrix(A[i+1]),Phi,T);
	int i=k-1;
	f[i]=ILocalMap(x[i],x[i+1],A[i],gaussInverseMatrix(A[i+1]),P);
	return f;
}

// // // // cone propagation // // // //

IVector ILocalMap::propagateCone(const IVector &x,const IVector &Cone,int n) const
{
	IMatrix DF=derivative(midVector(x));
	IVector y=x;
    
	for(int i=0;i<n;i++)
	{
		y[0]=part(x[0],n,i);
		DF=intervalHull(DF,derivative(y));
	}
    
	return PropagateCone(DF,Cone);
}

