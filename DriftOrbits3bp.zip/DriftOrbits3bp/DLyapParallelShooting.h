#ifndef DLyapParallelShooting_h
#define DLyapParallelShooting_h
#include "capd/capdlib.h"
using namespace capd;
using namespace std;

DVector S(DVector x);

////////////////////////////
// Function: LyapParallelShooting()
//
// This function creates points on Lyapunov orbit using non-rigorous computations and Newton's method
// It returns a vector of the form:
// p=(q0,w1,w2,...,wn,t)
// where wi = wi_1,wi_2,wi_3,wi_4
// From this vector we can recover points:
//   w0=(x,0,0,q0)
//   w1
//   w2
//   ...
//   wn
// which lie on the Lyapunov orbit, as well as the time t such that
//   Phi(t,wi)=wi+1  for i=0,...,n-1.
// The points w0,...,wn for `a half' of the orbit. To be more precise, the points have the property that
//   Phi(t,wn)=(x*,0,0,py*) 
// for some x*, py*. This means that
//   w0,...,wn,Phi(t,wn)  
// consist of the full half turn around the Lyapunov orbit, and the rest can be recovered from the symmetry property
//
// Purpose: This function computes the initial guess for the IVector version of parallel shooting. 
// The IVector version performs a computer assisted proof of an enclosure of points on the Lyapunov orbit,
// by using the Krawczyk method. The Krawczyk method requires an approximate inverse of the derivative of the 
// parallel shooting operator. This approximate inverse is computed as the matrix C in below routine.
DVector LyapParallelShooting(double x, int n, DMatrix &C, DMap &F, DTimeMap &Phi);

// This function recovers the sequence of points around the Lyapunov orbit:
vector<DVector> pointsOnLyapOtbit(double x,DVector p,DTimeMap &Phi,double &t);

#endif
