#include "ILyapParallelShooting.h"
#include "OperationsForShooting.h"
#include "DLyapParallelShooting.h"
#include "utils.h"
#include "constants.h"

////////////////////////////////////
// The function for our parallel shooting is
// F(q) = F(q0,w1,w2,...,wn,t)
//      = (Phi(t,(x,0,0,q0))-w1,
//         Phi(t,w1)-w2,
//         Phi(t,wn-1)-wn,
//         pi_y  o Phi(t,wn),
//         pi_px o Phi(t,wn))
//
// The function takes a vector q=(q0,w1,w2,...,wn,t) and computes p=F(q);
IVector Function(interval x,IVector q, ITimeMap &Phi, int n)
{
	IVector p(2+4*n), w(4);
	interval t=q[1+4*n];

    w[0]=x;
    w[1]=0.0;
    w[2]=0.0;
    w[3]=q[0];
    C0Rect2Set Q(w);
    
    Insert(p,Phi(t,Q)-PullOut(q,1),1); // phi(T,(x,0,0,q0)) - (q1,q2,q3,q4)
    
	for(int j=1;j<n;j++)
	{
		C0Rect2Set Q(PullOut(q,j));
		Insert(p,Phi(t,Q)-PullOut(q,j+1),j+1); // on place j+1 into p I insert Phi_t(x_j) - x_j+1
	}
    
	C0Rect2Set S(PullOut(q,n));
	w=Phi(t,S);
    
	p[4*n]=w[1]; // projection on coordinate y
	p[4*n+1]=w[2]; // projection on coordinate px
	return p;
}

// This computes the derivative of above function:
IMatrix Derivative(interval x,IVector q, ITimeMap &Phi, IMap &F, int n)
{
	IMatrix DF(2+4*n,2+4*n), DPhi(4,4);
	IVector w(4);
	interval t=q[1+4*n];
    
    w[0]=x;
    w[1]=0.0;
    w[2]=0.0;
    w[3]=q[0];
    C1Rect2Set Q(w);
    Phi(t,Q,DPhi);
    PutFirst(Column(DPhi,3),DF);
    InsertLastColumn(F(w),DF,0);
    
    PutId(DF,n); 
	
	for(int j=1;j<n;j++)
	{
		C1Rect2Set Q(PullOut(q,j));
		w=Phi(t,Q,DPhi);
		InsertLastColumn(F(w),DF,j);
		PutIn(DPhi,DF,j);
	}
    
    C1Rect2Set S(PullOut(q,n));
    
	w=Phi(t,S,DPhi);
                 
	PutLast(Row(DPhi,1),DF,n);
	PutSecondLast(Row(DPhi,2),DF,n);

	DF[4*n][1+4*n]=F(w)[1];
	DF[1+4*n][1+4*n]=F(w)[2];
	    
	return DF;
}


////////////////////////////
// Function: LyapParallelShooting()
//
// This function computes and validates points on Lyapunov orbit using rigorous computations and Krawczyk method
// It returns a vector of the form:
// p=(q0,w1,w2,...,wn,t)
// where wi = wi_1,wi_2,wi_3,wi_4
// From this vector we can recover points:
//   w0=(x,0,0,q0)
//   w1
//   w2
//   ...
//   wn
// which lie on the Lyapunov orbit, as well as the time t such that
//   Phi(t,wi)=wi+1  for i=0,...,n-1
// The points w0,...,wn for `a half' of the orbit. To be more precise, the points have the property that
//   Phi(t,wn)=(x*,0,0,py*) 
// for some x*, py*. This means that
//   w0,...,wn,Phi(t,wn)  
// consist of the full half turn around the Lyapunov orbit, and the rest can be recovered from the symmetry property
//
// Note:
// The Krawczyk method requires an approximate inverse of the derivative of the 
// parallel shooting operator. This approximate inverse is passed to the function as the matrix C.
IVector LyapParallelShooting(interval x,IVector p_guess, int n, IMatrix &C, IMap &F, ITimeMap &Phi)
{
    IVector p0=p_guess; // interval version of estimated q by non-rigorous ParallelShooting
    IVector p=p_guess;
    int dim=p0.dimension();
    IMatrix Id(dim,dim);
    for(int i=0;i<dim;i++) Id[i][i]=1.0;
    
    for(int i=0;i<5;i++)
    {
        p = p0 + C*Function(x,p0,Phi,n) + (Id-C*Derivative(x,p,Phi,F,n))*(p-p0);
    }
	
    for(int i=0;i<dim;i++) p[i]=p[i].mid()+1.5*(p[i]-p[i].mid());

    // Krawczyk's operator: 
    IVector K = p0 + C*Function(x,p0,Phi,n) + (Id-C*Derivative(x,p,Phi,F,n))*(p-p0);
    
    if(subsetInterior(K,p)==0)
    {
        cout << "Validation of the Lyapunov orbit failed. Aborting program." << endl;
        abort();
    }
    return p;
}

IVector S(IVector x)
{
	x[1]=-x[1];
	x[2]=-x[2];
	return x;
}

inline interval timeBetweenPointsOnLyapOtbit(IVector p){return p[(int)p.dimension()-1];}

// This function recovers the sequence of 2n+2 points around the Lyapunov orbit, from the p computed using parallel shooting:
vector<IVector> pointsOnLyapOtbit(interval x,IVector p,ITimeMap &Phi,interval &t)
{
	t=timeBetweenPointsOnLyapOtbit(p);
	int n=(p.dimension()-2)/4;
	vector<IVector> w(2*n+2);
	w[0]=IVector(4);
	w[0][0]=x;
	w[0][3]=p[0];
	
	for(int i=1;i<=n;i++) w[i]=PullOut(p,i);
	C0Rect2Set X(w[n]);
	w[n+1]=Phi(t,X);
	
	for(int i=1;i<=n;i++) w[n+1+i]=S(w[n+1-i]);
	return w;
}

vector<IVector> pointsOnLyapOrb(interval x,ITimeMap &Phi,IMap &F,int n,interval &t)
{
    DMap F_ = "par:mu;var:X,Y,PX,PY;fun:PX+Y,PY-X,PY-X+(X-(1-mu)*(X-mu)*((X-mu)^2+Y^2)^(-1.5)-mu*(X-mu+1)*((X-mu+1)^2+Y^2)^(-1.5)),-PX-Y+(Y-(1-mu)*Y*((X-mu)^2+Y^2)^(-1.5)-mu*Y*((X-mu+1)^2+Y^2)^(-1.5));";
    F_.setParameter("mu",mu);
    DOdeSolver solver_(F_,TAYLOR_ORDER);
	DTimeMap Phi_(solver_);
	
	// computation of initial guess:
	DMatrix C_;
	DVector p_=LyapParallelShooting(toDouble(x),n,C_,F_,Phi_);
	
	// validation using Krawczyk Method:
	IVector p=toInterval(p_);
	IMatrix C=toInterval(C_);
	p=LyapParallelShooting(x,p,n,C,F,Phi);
	
	return pointsOnLyapOtbit(x,p,Phi,t);
}


