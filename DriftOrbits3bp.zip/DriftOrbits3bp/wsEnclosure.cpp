#include "wsEnclosure.h"

void validateWsEnclosure(vector<IMatrix> &A,vector<IVector> &Cone)
{
	IMatrix S(4,4);
	S[0][0]=interval(1);
	S[1][1]=-interval(1);
	S[2][2]=-interval(1);
	S[3][3]=interval(1);
	int k=A.size();
	for(int i=0;i<k;i++) A[i]=S*A[i];
	vector<IMatrix> B=A;
	vector<IVector> cone=Cone;
	// we now renumber the cones and coordinate changes so that the fibers are based at p[i] that flows to p[i+1]
	for(int i=1;i<k;i++)
	{
		A[i]=B[k-i];
		Cone[i]=cone[k-i];
	}
}
