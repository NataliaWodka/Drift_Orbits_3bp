#include "DHomParallelShooting.h"
#include "constants.h"
#include "OperationsForShooting.h"
#include "DLyapParallelShooting.h" // needed for S

double timeToSection(DVector p0,DMatrix A,DVector v,int side)
{
    DMap F("par:mu;var:X,Y,PX,PY,t;fun:PX+Y,PY-X,PY-(1-mu)*(X-mu)*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*(X-mu+1)*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5),-PX-(1-mu)*Y*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*Y*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5),1.0;");
    F.setParameter("mu",mu);
    DCoordinateSection section(5,1);
    DOdeSolver solver(F,TAYLOR_ORDER);
    DTimeMap Phi(solver);
    DPoincareMap P(solver,section);

    DVector q=p0+A*v;
    DVector p(5);
    for(int i=0;i<4;i++) p[i]=q[i];
    
    //while(p[0]<0.0)
	if(side==1)  while(p[0]<0.0)  p=P(p);
	if(side==-1) while(p[0]>-1.0) p=P(p);
    
    return p[4];
}

DVector Function(DVector q, DTimeMap &Phi, DMatrix A, DVector p0, int n)
{
    DVector p(2+4*n), v(4), w(4);
    double t=q[1+4*n];
    
    v[0]=q[0];    
    DVector x=p0+A*v;
    Insert(p,Phi(t,x)-PullOut(q,1),1);

    
    for(int j=1;j<n;j++)
    {
        DVector temp(4);
        temp=PullOut(q,j);
        Insert(p,Phi(t,temp)-PullOut(q,j+1),j+1);
    }
    
    w=PullOut(q,n);
    w=Phi(t,w);
    p[4*n]=w[1];
    p[4*n+1]=w[2];
    return p;
}

DMatrix Derivative(DVector q, DTimeMap &Phi, DMap &F, DMatrix A, DVector p0, int n)
{
    DMatrix DF(2+4*n,2+4*n), DPhi(4,4);
    DVector x(4), v(4), w(4), y(4), A1(4);
    double t=q[1+4*n];

    v[0]=q[0];
    x=p0+A*v;
    A1=Column(A,0); // derivative wrt q0

    w=Phi(t,x,DPhi);
    PutFirst(DPhi*A1,DF);
    
    InsertLastColumn(F(w),DF,0);

    for(int j=1;j<n;j++)
    {
        w=PullOut(q,j);
        w=Phi(t,w,DPhi); // now DPhi(w=x_j), and then new vector w is x_j+1
        InsertLastColumn(F(w),DF,j);
        PutIn(DPhi,DF,j); // we put derivative of Phi_t in x_j on the place j in DF
    }
    
    w=PullOut(q,n);
    
    y=Phi(t,w,DPhi);
    
    PutLast(Row(DPhi,1),DF,n);
    PutSecondLast(Row(DPhi,2),DF,n);

    PutId(DF,n); // we put -Id
    
    DF[4*n][1+4*n]=F(y)[1];
    DF[1+4*n][1+4*n]=F(y)[2];
    
    return DF;
}

DVector HomoclinicParallelShooting(DVector p0,DMatrix A,int n, double h, DMatrix &C,DMap &F,DTimeMap &Phi)
{    
    DVector q(2+4*n), w(4), v(4);
    q[0]=h;
    v[0]=h;
    w=p0+A*v;
    
	int side=1;
	if(h<0) side=-1;
	
    double t=timeToSection(p0,A,v,side)/(n+1.0);
    q[4*n+1]=t;
    
    for(int l=1;l<n+1;l++)
    {
        w=Phi(t,w);
        int j=0;
        for(int i=1+4*(l-1);i<1+4*l;i++)
        {
            q[i]=w[j];
            j++;
        }
    }

	
    for(int i=0;i<20;i++)
    {
        q=q-gauss(Derivative(q,Phi,F,A,p0,n),Function(q,Phi,A,p0,n));// Newton's method
		//cout << " " << Function(q,Phi,A,p0,n) << endl;
    }
	//for(int i=0;i<q.dimension();i++) cout << q[i] << endl;
    C=gaussInverseMatrix(Derivative(q,Phi,F,A,p0,n));// matrix made for Krawczyk's method
    return q;
}

inline double timeBetweenPointsOnHomoclinic(DVector p){return p[(int)p.dimension()-1];}

vector<DVector> homoclinic(DVector p,DVector p0,DMatrix A,DTimeMap &Phi,double &t)
{
	t=timeBetweenPointsOnHomoclinic(p);
	DVector v(4);
	v[0]=p[0];
	
	int n=(p.dimension()-2)/4;
	vector<DVector> w(2*n+3);
	w[0]=p0+A*v;
	
	for(int i=1;i<=n;i++) w[i]=PullOut(p,i);
	DVector dummy=w[n];
	w[n+1]=Phi(t,dummy);
	
	for(int i=1;i<=n+1;i++) w[n+1+i]=S(w[n+1-i]);
	return w;
}
