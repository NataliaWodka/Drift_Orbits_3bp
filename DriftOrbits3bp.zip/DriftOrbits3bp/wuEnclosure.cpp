#include "wuEnclosure.h"
#include "LyapOrb.h"
#include "utils.h"
#include "LocalMap.h"
#include "eigenvector.h"
using namespace capd::matrixAlgorithms;

////////////////////////////////////////////////////
// Function: GershgorinEigenvalueBound()
// 
// Purpose: computes the bound on the first eigenvalue using the Gershgorin theorem.
//
// Note: To apply this function, the matrix A needs to be in the form that is close to
// diagonal. The entries outside of the diagonal need to be small in order to obtain 
// sharp estimates.
interval GershgorinEigenvalueBound(const IMatrix &A)
{
   int m=A.numberOfColumns();
   interval h=A[0][1]*interval(-1.0,1.0);
   for(int i=2;i<m;i++)
   {
       h=h+A[0][i]*interval(-1.0,1.0);
   }
   return A[0][0]+h;
}

// The important issue for us is that the eigenvalues of A and P^{-1}*A*P are the same, no matter what matrix P
// we choose. Here we choose a matrix P which brings A "close" to the Jordan form.
// We write "close" because the change P is computed using non-rigorous numerics.
// Once the P is chosen though, we compute its inverse using interval arithmetic, so P^{-1}*A*P are sure 
// to have the same eigenvalues as A.
IMatrix closeToJordanForm(const IMatrix &A)
{
	DMatrix B=toDouble(A);
	int n=A.numberOfColumns();
	DVector rE(n), iE(n);
	DMatrix rVec(n,n), iVec(n,n);
	computeEigenvaluesAndEigenvectors(B,rE,iE,rVec,iVec);
	IMatrix P=toInterval(rVec+iVec);
	return gaussInverseMatrix(P)*A*P;
}

// The point p[0] lies on the Lyapunov orbit. Here we compute DPhi(T,p[0]), where T is the period of the 
// Lyapunov orbit. Since we know the bound on the sequence of points p[0],...,p[n-1] which lie on the Lyapunov orbit,
//    Phi(t,p[i])=p[i+1]
//    Phi(t,p[n-1])=p[0]
// we can compute 
//    DPhi(T,p[0])=DPhi(t,p[n-1])*...*DPhi(t,p[0])
// This gives sharper bounds than integrating from p[0] for the full time T. 
IMatrix computeDerivative(const vector<IVector> &p,interval t,ITimeMap &Phi,IPoincareMap &P)
{
	IMatrix DF(4,4);
	for(int i=0;i<4;i++) DF[i][i]=1.0;
	int n=p.size();
	for(int i=0;i<n-1;i++)
	{
		IMatrix DPhi(4,4);
		C1Rect2Set Q(p[i]);
		Phi(t,Q,DPhi);
		DF=DPhi*DF;
	}
	IMatrix DP(4,4);
	C1Rect2Set Q(p[n-1]);
	IVector y=P(Q,DP);
	DP=P.computeDP(y,DP);
	DF=DP*DF;
	return DF;
}

interval computeEigenvalue(const vector<IVector> &p,interval t,ITimeMap &Phi,IPoincareMap &P)
{
	return GershgorinEigenvalueBound(closeToJordanForm(computeDerivative(p,t,Phi,P)));
}

bool coneConditions(const vector<ILocalMap> &f,interval range,IVector cone,int d)
{
	IVector cone0=cone;
	int k=f.size();
	for(int i=0;i<k;i++)
	{
		IVector X=range*interval(-1,1)*cone;
		cone=f[i].propagateCone(X,cone,d);
	}
	if(subset(cone,cone0)==1) return 1;
	return 0;
}

bool coneConditions(const vector<ILocalMap> &f,interval &L, interval range,int d,vector<IVector> &Cone)
{
	IVector cone(4);
	cone[0]=1;
	for(int i=1;i<4;i++) cone[i]=L*interval(-1,1);
	Cone.push_back(cone);
	
	int k=f.size();
	for(int i=0;i<k;i++)
	{
		IVector X=range*interval(-1,1)*Cone[i];
		X[0]=interval(-1.0,1.0)*range; 
		Cone.push_back(f[i].propagateCone(X,Cone[i],d));
	}
	if(subset(Cone[k],cone)==1) return 1;
	Cone.pop_back();
	return 0;
}

interval maxConeCoeff(IVector cone)
{
	interval a=abs(cone[1]).right();
	if(abs(cone[2]).right()>a) a=abs(cone[2]).right();
	if(abs(cone[3]).right()>a) a=abs(cone[3]).right();
	return a;
}

IMatrix A12(const IMatrix &Df)
{
	IMatrix A(1,3);
	for(int i=0;i<3;i++) A[0][i]=Df[0][i+1];
	return A;
}

IMatrix A21(const IMatrix &Df)
{
	IMatrix A(3,1);
	for(int i=0;i<3;i++) A[i][0]=Df[i+1][0];
	return A;
}

IMatrix A22(const IMatrix &Df)
{
	IMatrix A(3,3);
	for(int i=0;i<3;i++) 
		for(int k=0;k<3;k++)
			A[i][k]=Df[i+1][k+1];
	return A;
}

void expansionCondition(const vector<ILocalMap> &f,interval range,const vector<IVector> &Cone,interval &m,interval &mbar)
{
	IMaxNorm Norm;
	interval a;
	int k=f.size();
	
	interval globalLowerExpansionCoefficient;
	interval localLowerExpansionCoefficient;
	
	interval globalUpperExpansionCoefficient;
	interval localUpperExpansionCoefficient;
	
	interval L=Cone[0][1].right();
	interval I=Cone[0][1];
	IMatrix Df(4,4);
    
    for(int i=0;i<k;i++)
    {
		a=maxConeCoeff(Cone[i]);
	    IVector X=range*Cone[i];
	    X[0]=interval(-1.0,1.0)*X[0];
		Df=f[i][X];
		localLowerExpansionCoefficient=abs(Df[0][0]).right()-a*Norm(A12(Df));
		localUpperExpansionCoefficient=max(abs(Df[0][0]).right()+a*Norm(A12(Df)),Norm(A21(Df))+a*Norm(A22(Df))).right();
		
        if( not(localLowerExpansionCoefficient>1.0) ) 
		{
			cout << "Expansion condition failed. Aborting program. " << endl;
			abort();
		}
		if(i==0) globalLowerExpansionCoefficient=localLowerExpansionCoefficient;
		if(i>0)  globalLowerExpansionCoefficient=intervalHull(globalLowerExpansionCoefficient,localLowerExpansionCoefficient).left();
		if(i==0) globalUpperExpansionCoefficient=localUpperExpansionCoefficient;
		if(i>0)  globalUpperExpansionCoefficient=intervalHull(globalUpperExpansionCoefficient,localUpperExpansionCoefficient).right();
    }
    m=globalLowerExpansionCoefficient;
	mbar=globalUpperExpansionCoefficient;
}

bool validateWuEnclosure(vector<IVector> p,interval t,vector<IMatrix> &A,interval &L,interval range,ITimeMap &Phi,int d,interval &m,interval &mbar,IPoincareMap &P,vector<IVector> &Cone)
{
	interval lambda = computeEigenvalue(p,t,Phi,P);
	if(!(lambda>1.0))
	{ 
		cout << "The bound on the eigenvalue failed." << endl;
		return 0;
	}	
	p.push_back(p[0]);
	
	int n=A.size()-1;
	A[n]=A[0];
	
	vector<ILocalMap> f=LocalMap(p,A,Phi,t,P);
	
	if(coneConditions(f,L,range,d,Cone)==0)
	{ 
		cout << "cone condition failed." << endl;
		return 0;
	}
	
	expansionCondition(f,range,Cone,m,mbar); // this computes m and mbar
	return 1;
}

bool validateFiberInExtendedPhaseSpace(vector<IVector> p,interval t,vector<IMatrix> A,interval L,interval M,interval range,ITimeMap &Phi,IPoincareMap &P,int d)
{
	p.push_back(p[0]);
	p=to5dim(p);
	A=to5dim(A);
	vector<ILocalMap> f=LocalMap(p,A,Phi,t,P);
	
	IMatrix DF(5,5);
	for(int i=0;i<5;i++) DF[i][i]=1.0;
	int n=f.size();
	IVector zero(5);
	for(int i=0;i<n;i++) 
	{
		DF=(f[i])[zero]*DF;
	}
	
	// computation for the candidate for the eigenvector and eigenvalue
	DMatrix B=toDouble(DF);
    DVector rE(5), iE(5);
    DMatrix rVec(5,5), iVec(5,5);
    computeEigenvaluesAndEigenvectors(B,rE,iE,rVec,iVec);
	
	interval lambda=rE[0];
	IVector v(5);
	for(int i=0;i<5;i++) v[i]=rVec[i][0];
	interval b=0.000001*interval(-1,1);
	for(int i=1;i<4;i++) v[i]=v[i]+b;
	v[0]=v[0]+0.001*interval(-1,1);
	lambda=lambda+5*interval(-1,1);
	
	if(containsEigenvalueAndEigenvector(DF,lambda,v)==0) return 0;
	v=(interval(1.0)/v[0])*v;
	v[0]=1;
	cout << "DF in extended phase space = " << DF << endl;
	cout << "Established unstable eigenvector in extended phase space = " << v << endl;
	
	IVector cone(5);
	cone[0]=1;
	for(int i=1;i<4;i++) cone[i]=L*interval(-1,1);
	cone[4]=M*interval(-1,1);
	cout << "Cone in extended phase space = " << cone << endl;
	if(subset(v,cone)==0) return 0;
	
	if(coneConditions(f,range,cone,d)==1) return 1;
	return 0;
}