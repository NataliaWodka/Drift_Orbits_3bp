#ifndef LyapOrb_h
#define LyapOrb_h

#include <iostream>
#include <time.h>
#include "capd/capdlib.h"

using namespace capd;
using namespace std;
using namespace capd::alglib;
using namespace capd::matrixAlgorithms;

//////////////////////////
// Function: LyapPoint(x)
// This computes a point 
//  (x,0,0,py(x))
// on a Lyapunov orbit.   
DVector LyapPoint(double x);

//////////////////////////
// Function: timeToSection(q)
// This function computes the time needed for the flow to reach the section {Y=0} from q.
double timeToSection(DVector q);




#endif
