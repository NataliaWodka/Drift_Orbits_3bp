#include "IHomParallelShooting.h"
#include "DHomParallelShooting.h"
#include "ILyapParallelShooting.h"
#include "OperationsForShooting.h"
#include "LocalMap.h"
#include "constants.h"
#include "utils.h"

////////////////////////////////////
// The function for our parallel shooting is
// F(q) = F(q0,w1,w2,...,wn,t)
//      = (Phi(t,Wu(q0))-w1,
//         Phi(t,w1)-w2,
//         Phi(t,wn-1)-wn,
//         pi_y  o Phi(t,wn),
//         pi_px o Phi(t,wn))
//
// We know that 
//    Wu(q0) \in p0+q0*A*v
// and
//    dWu(q0) \in v
// where v=(1,L*[-1,1],L*[-1,1],L*[-1,1])
// The function takes a vector q=(q0,w1,w2,...,wn,t) and computes p=F(q);
IVector Function(IVector q, ITimeMap &Phi, IMatrix A, IVector p0, interval L, int n)
{
	IVector p(2+4*n), v(4);
	interval t=q[1+4*n];
	
	v[0]=1;
	for(int i=1;i<4;i++) v[i]=L*interval(-1.0,1.0);
    IVector v0=midVector(v); 
	// Q = p0+q0*A*v = p0+q0*A*v0+A*q0*(v-v0)
	C0Rect2Set Q(p0+q[0]*A*v0,A,q[0]*(v-v0)); 
	
	Insert(p,Phi(t,Q)-PullOut(q,1),1); 

	for(int j=1;j<n;j++)
	{
		Q=C0Rect2Set(PullOut(q,j));
		Insert(p,Phi(t,Q)-PullOut(q,j+1),j+1); // on place j+1 into p I insert Phi_t(x_j) - x_j+1
	}
	Q=C0Rect2Set(PullOut(q,n));
    IVector w=Phi(t,Q);
	p[4*n]=w[1];
    p[1+4*n]=w[2];
    
	return p;
}
// This computes the derivative of above function:
IMatrix Derivative(IVector q, ITimeMap &Phi, IMap &F, IMatrix A, IVector p0, interval L, int n)
{
	IMatrix DF(2+4*n,2+4*n), DPhi(4,4), DP(4,4);
	IVector v(4), v0(4);

	v[0]=1;
	v0=midVector(v);
	for(int i=1;i<4;i++) v[i]=L*interval(-1.0,1.0);
    interval t=q[1+4*n];
	
	IVector dWu=v;
	
	// Q = p0+q0*A*v = p0+q0*A*v0+A*q0*(v-v0)
	C1Rect2Set Q(p0+q[0]*A*v0,A,q[0]*(v-v0));
	IVector w=Phi(t,Q,DPhi);
    
    InsertLastColumn(F(w),DF,0);
	
	PutFirst(DPhi*A*dWu,DF);
	
	for(int j=1;j<n;j++)
	{
		C1Rect2Set Q(PullOut(q,j));
		w=Phi(t,Q,DPhi);
        InsertLastColumn(F(w),DF,j);
		PutIn(DPhi,DF,j);
	}
	
	Q=C1Rect2Set(PullOut(q,n));
    IVector y=Phi(t,Q,DPhi);
    
    PutLast(Row(DPhi,1),DF,n);
    PutSecondLast(Row(DPhi,2),DF,n);

	PutId(DF,n);
    
    DF[4*n][1+4*n]=F(y)[1];
    DF[1+4*n][1+4*n]=F(y)[2];

	return DF;
}

IVector HomoclinicParallelShooting(IVector p0,IMatrix A,interval L,IVector p_guess,interval range,int n,IMatrix C,IMap &F,ITimeMap &Phi)
{
    IVector p=p_guess;
	//return p;
    int dim=p_guess.dimension();
    IMatrix Id(dim,dim);
    for(int i=0;i<dim;i++) Id[i][i]=1.0;
    
    for(int i=0;i<2;i++)
    {
        p = p_guess + C*Function(p_guess,Phi,A,p0,L,n) + (Id-C*Derivative(p,Phi,F,A,p0,L,n))*(p-p_guess);
		//cout << p-midVector(p) << endl;
    }
	for(int i=0;i<dim;i++) p[i]=p[i].mid()+1.5*(p[i]-p[i].mid());
	
	//for(int i=0;i<dim;i++) p[i]=power(10,-7)*interval(-1,1);

    // // // Krawczyk's operator // // //
    IVector K = p_guess + C*Function(p_guess,Phi,A,p0,L,n) + (Id-C*Derivative(p,Phi,F,A,p0,L,n))*(p-p_guess);
	
    if(subsetInterior(K,p)==0)
		{cout << "Proof of homoclinic orbit failed. (1). Aborting program" << endl; abort();}
	if(not(subsetInterior(p[0],range*interval(-1,1))))
		{cout << "Proof of homoclinic orbit failed. (2). Aborting program" << endl << "h=" << p[0] << endl; abort();}
	
    return p;
}

inline interval timeBetweenPointsOnHomoclinic(IVector p){return p[(int)p.dimension()-1];}

vector<IVector> homoclinic(IVector p,IVector p0,IMatrix A,ITimeMap &Phi,interval &t)
{
	t=timeBetweenPointsOnHomoclinic(p);
	IVector v(4);
	v[0]=p[0];
	
	int n=(p.dimension()-2)/4;
	vector<IVector> w(n+1);
	w[0]=p0+A*v;
	
	for(int i=1;i<=n;i++) w[i]=PullOut(p,i);
	//C0Rect2Set Q(w[n]);
	//w[n+1]=Phi(t,Q);
	
	return w;
}

vector<IVector> pointsOnHomoclinic(IVector p0,IMatrix A,interval L,interval range,ITimeMap &Phi,IMap &F,int n,interval &t,interval &h)
{
	// computing the candidate for the solution:
    DMap F_("par:mu;var:X,Y,PX,PY;fun:PX+Y,PY-X,PY-(1-mu)*(X-mu)*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*(X-mu+1)*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5),-PX-(1-mu)*Y*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*Y*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5);");
    F_.setParameter("mu",mu);
    DOdeSolver solver_(F_,TAYLOR_ORDER);
    DTimeMap Phi_(solver_);
	
	DMatrix C;
    IVector p=toInterval(HomoclinicParallelShooting(toDouble(p0),toDouble(A),n,toDouble(h),C,F_,Phi_));
	h=p[0];
	
	// Computing the points using the Krawczyk method
	p=HomoclinicParallelShooting(p0,A,L,p,range,n,toInterval(C),F,Phi);
	// extending the half orbit to full orbit by using symmetry
	// this also computes t
	return homoclinic(p,p0,A,Phi,t);
}

////////////////////////////////////////////////
vector<IMatrix> coordinatesAlongHomoclinic(const vector<IVector> &q_,interval s_,IMatrix A_)
{
	int n=q_.size();
	vector<DVector> q=toDouble(q_);
	double s=toDouble(s_);
	vector<DMatrix> A(n);
	A[0]=toDouble(A_);
	
    DMap F("par:mu;var:X,Y,PX,PY;fun:PX+Y,PY-X,PY-(1-mu)*(X-mu)*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*(X-mu+1)*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5),-PX-(1-mu)*Y*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*Y*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5);");
    F.setParameter("mu",mu);
    DOdeSolver solver(F,TAYLOR_ORDER);
    DTimeMap Phi(solver);
	
	DEuclNorm N;
	for(int i=0;i<n-1;i++)
	{
		DMatrix DPhi(4,4);
		Phi(s,q[i],DPhi);
		A[i+1]=DPhi*A[i];
		A[i+1]=(1.0/N(A[i+1]))*A[i+1];
	}
	return toInterval(A);
}

/*bool establishTransversality(const vector<IVector> &q,interval s,IMatrix A,interval L,ITimeMap &Phi,IPoincareMap &P)
{
	IVector v(4);
	v[0]=1.0;
	for(int i=1;i<4;i++) v[i]=L*interval(-1,1);
	
	vector<IMatrix> B=coordinatesAlongHomoclinic(q,s,A);
	vector<ILocalMap> f=LocalMap(q,B,Phi,s);
	
	int n=f.size();
	
	IVector zero(4);
	for(int i=0;i<n;i++)
	{
		//v=f[i].propagateCone(zero,v,1);
		cout << f[i][zero] << endl;
		//cout << v << endl;
	}
	
	C1Rect2Set Q(q[n]);
	IMatrix DPhi,DP;
	IVector p=P(Q,DPhi);
	DP=P.computeDP(p,DPhi);
	v=(DP*B[n])*v;
	v=v/v[0].mid();
	if(not (v[0]>0.0)){cout << "v = " << v << endl; return 0;}
	if(not (v[2]>0.0)){cout << "v = " << v << endl; return 0;}
	return 1;
}*/

/*bool establishTransversality2(const vector<IVector> &q,interval s,IMatrix A,interval L,ITimeMap &Phi,IPoincareMap &P)
{
	IVector v(4);
	v[0]=1.0;
	for(int i=1;i<4;i++) v[i]=L*interval(-1,1);
	// in our local coordinates the last coordinate is associated with the section.
	// from the construction in validateWuEnclosure() we are sure that the fiber is on the section, hence we can set this coordinate to zero.
	v[3]=0.0;
	
	int n=q.size()-1;
	v=A*v;
	for(int i=0;i<n-1;i++)
	{
		C1Rect2Set Q(q[i]);
		IMatrix DPhi;
		Phi(s,Q,DPhi);
		v=DPhi*v;
	}
	
	C1Rect2Set Q(q[n-1]);
	IMatrix DPhi,DP;
	IVector p=P(Q,DPhi);
	DP=P.computeDP(p,DPhi);
	v=DP*v;
	v=v/v[0].mid();
	if(not (v[0]>0.0)){cout << "v = " << v << endl; return 0;}
	if(not (v[2]>0.0)){cout << "v = " << v << endl; return 0;}
	cout << "The cone bounds at the intersection of the manifolds are: " << v << endl;
	return 1;
}*/

bool establishTransversality(const vector<IVector> &q,interval s,IMatrix A,interval L,ITimeMap &Phi,IPoincareMap &P)
{
	IVector v(4);
	v[0]=1.0;
	for(int i=1;i<4;i++) v[i]=L*interval(-1,1);
	
	int n=q.size()-1;
	int N=5;
	if(not((n % N)==0)) 
	{
		cout << "problem with establishTransversality() function " << endl;
		abort();
	}
	int k=n/N;
	
	for(int i=0;i<N-1;i++)
	{
		C1Rect2Set Q(q[i*k]);
		IMatrix DPhi;
		Phi(s*k,Q,DPhi);
		A=DPhi*A;
	}
	
	C1Rect2Set Q(q[(N-1)*k]);
	IMatrix DPhi,DP;
	IVector p=P(Q,DPhi);
	DP=P.computeDP(p,DPhi);
	A=DP*A;
	v=A*v;
	v=v/v[0].left();
	v[0]=v[0].left();
	if(not (v[0]>0.0)){cout << "v = " << v << endl; return 0;}
	if(not (v[2]>0.0)){cout << "v = " << v << endl; return 0;}
	cout << "The cone bounds at the intersection of the manifolds are: " << v << endl;
	return 1;
}

vector<IVector> pointsOnFullHomoclinic(vector<IVector> p,ITimeMap &Phi,interval t)
{
	int n=p.size();
	C0Rect2Set Y=C0Rect2Set(p[n-1]);
	IVector y=Phi(t,Y);
	// from the theory we know that we are enclosing S-symmetric homoclinic orbits. We can make use of this knowledge here:
	y[1]=0.0;
	y[2]=0.0; 
	p.push_back(y);
	for(int i=0;i<n-1;i++)
	{
		p.push_back(S(p[n-1-i]));	
	}
	return p;
}

