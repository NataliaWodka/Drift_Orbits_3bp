#include "plots.h"
#include "utils.h"
#include "constants.h"
#include "MelnikovComputation.h"
void plot(interval x,interval y,ofstream &file)
{
	file << 
	x.mid().leftBound() << " " << 
	y.mid().leftBound() << " " << 
	x.rightBound() - x.mid().leftBound() << " " <<
	y.rightBound() - y.mid().leftBound() <<	 endl;
}

// This function was used to produce the plot of the homoclinic orbit in the proof
void plotHomoclinic(const vector<IVector> &p,interval h)
{
	DMap F("par:mu;var:X,Y,PX,PY;fun:PX+Y,PY-X,PY-(1-mu)*(X-mu)*((X-mu)^2+Y^2)^(-1.5)-mu*(X-mu+1)*((X-mu+1)^2+Y^2)^(-1.5),-PX-(1-mu)*Y*((X-mu)^2+Y^2)^(-1.5)-mu*Y*((X-mu+1)^2+Y^2)^(-1.5);");
 	F.setParameter("mu",mu); 
	DOdeSolver solver(F,TAYLOR_ORDER);
	DTimeMap Phi(solver);
	double t=h.mid().leftBound();
	
	ofstream file("plots/homoclinic.txt");
	ofstream file2("plots/homoclinicP.txt");
	
	int n=p.size();
	for(int i=0;i<n;i++) file2 << p[i][0].mid().leftBound() << " " << p[i][1].mid().leftBound() << endl;
	
	for(int i=0;i<n;i++)
	{
		DVector q=toDouble(p[i]);
		file << q[0] << " " << q[1] << endl;
		for(int j=0;j<50;j++)
		{
			q=Phi(t/50.0,q);
			file << q[0] << " " << q[1] << endl;
		}
	}
	file.close();
	file2.close();
}

void plotEnergyChange(vector<IVector> p,interval t,ITimeMap &Phi,IPoincareMap &P,IMap &H)
{
	ofstream file("plots/energyChange.txt");
	int n=1000;
	for(int i=0;i<n;i++)
	{
		cout << i << endl;
		interval theta=part(intervalHull(interval(0),2*interval::pi()),n,i);
		plot(theta,gI(p,theta,t,Phi,P,H),file);
	}
	file.close();
}