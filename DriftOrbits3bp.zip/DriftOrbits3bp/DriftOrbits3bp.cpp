#include <iostream>
#include <chrono>
#include <unistd.h>
#include "capd/capdlib.h"

#include "utils.h"
#include "constants.h"
#include "LyapOrb.h"
#include "DLyapParallelShooting.h"
#include "ILyapParallelShooting.h"
#include "wuEnclosure.h"
#include "wsEnclosure.h"
#include "persistenceOfNHIM.h"
#include "DHomParallelShooting.h"
#include "IHomParallelShooting.h"
#include "MelnikovComputation.h"
#include "plots.h"

using namespace capd;
using namespace std;
using namespace capd::alglib;
using namespace capd::matrixAlgorithms;

int main(int argc, char* argv[])
{
    time_t before,after;
    before=time(NULL);
  	try
    {
        cout.precision(7);
		// The PRC3BP vector field:
		IMap F("par:mu;var:X,Y,PX,PY;fun:PX+Y,PY-X,PY-(1-mu)*(X-mu)*((X-mu)^2+Y^2)^(-1.5)-mu*(X-mu+1)*((X-mu+1)^2+Y^2)^(-1.5),-PX-(1-mu)*Y*((X-mu)^2+Y^2)^(-1.5)-mu*Y*((X-mu+1)^2+Y^2)^(-1.5);");
	 	F.setParameter("mu",mu); // the constant mu is in constants.h
		
        // the flow of the PRC3BP:
        IOdeSolver solver(F,TAYLOR_ORDER);
        ITimeMap Phi(solver);
        // the section {y=0} to section map:
		ICoordinateSection section(4,1);
		IPoincareMap P(solver,section);
		
		// The the section {y=0} to section map of the PRC3BP in the extended phase space. (this is needed for the computation of the twist coefficient)
        IMap F_("par:mu;var:X,Y,PX,PY,t;fun:PX+Y,PY-X,PY-(1-mu)*(X-mu)*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*(X-mu+1)*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5),-PX-(1-mu)*Y*((X-mu)*(X-mu)+Y*Y)^(-1.5)-mu*Y*((X-mu+1)*(X-mu+1)+Y*Y)^(-1.5),1;");
        F_.setParameter("mu",mu);
        IOdeSolver solver_(F_,TAYLOR_ORDER);
		ICoordinateSection section_(5,1);
		ITimeMap Phi_(solver_);
		IPoincareMap P_(solver_,section_);
		
		IMap Fe("par:mu;var:X,Y,PX,PY,t,eps;fun:PX+Y,PY-X,PY-X+(X-(1-mu)*(X-mu)*((X-mu)^2+Y^2)^(-1.5)-mu*(X-mu+1)*((X-mu+1)^2+Y^2)^(-1.5))/(1.0+eps*cos(t)),-PX-Y+(Y-(1-mu)*Y*((X-mu)^2+Y^2)^(-1.5)-mu*Y*((X-mu+1)^2+Y^2)^(-1.5))/(1.0+eps*cos(t)),1.0,0.0;");
		Fe.setParameter("mu",mu);
        IOdeSolver solvere(Fe,TAYLOR_ORDER);
        ITimeMap Phie(solvere);
		ICoordinateSection sectione(6,1);
		IPoincareMap Pe(solvere,sectione);

		IMap He("par:mu;var:X,Y,PX,PY,t,e;fun:0.5*((PX+Y)^2+(PY-X)^2)-(0.5*(X^2+Y^2)+(1-mu)*((X-mu)^2+Y^2)^(-0.5)+mu*((X-mu+1)^2+Y^2)^(-0.5));",2);
		He.setParameter("mu",mu);
		
		IMap Omega("par:mu;var:X,Y,PX,PY;fun:(0.5*(X^2+Y^2)+(1-mu)*((X-mu)^2+Y^2)^(-0.5)+mu*((X-mu+1)^2+Y^2)^(-0.5));");
		Omega.setParameter("mu",mu);
		
		IMap H("par:mu;var:X,Y,PX,PY;fun:0.5*((PX+Y)^2+(PY-X)^2)-(0.5*(X^2+Y^2)+(1-mu)*((X-mu)^2+Y^2)^(-0.5)+mu*((X-mu+1)^2+Y^2)^(-0.5));");
		H.setParameter("mu",mu);
		
		IMap FeC2("par:mu;var:X,Y,PX,PY,t,eps;fun:PX+Y,PY-X,PY-X+(X-(1-mu)*(X-mu)*((X-mu)^2+Y^2)^(-1.5)-mu*(X-mu+1)*((X-mu+1)^2+Y^2)^(-1.5))/(1.0+eps*cos(t)),-PX-Y+(Y-(1-mu)*Y*((X-mu)^2+Y^2)^(-1.5)-mu*Y*((X-mu+1)^2+Y^2)^(-1.5))/(1.0+eps*cos(t)),1.0,0.0;",2);
		FeC2.setParameter("mu",mu);
        ICnOdeSolver solverC2(FeC2,TAYLOR_ORDER);
		ICnTimeMap PhieC2(solverC2);
		ICnPoincareMap PeC2(solverC2,sectione,poincare::MinusPlus);

		int k=14;
		
		// The interval of Lyapunov orbits which interests us:
		interval x=-0.95+1.0*pow(10.0,-9.0)*interval(0,1);

		//////////////////////////////////////////////////////////
		// 1.  computation of points around Lyapunov orbits    ///
		//////////////////////////////////////////////////////////
		interval t;
		vector<IVector> q=pointsOnLyapOrb(x,Phi,F,k,t);
		cout.precision(11);
		interval LyapPeriod=q.size()*t;
		cout << "Value of the Hamiltonian on the family of Lyapunov orbits:" << H(q[0]) << endl;
		cout << "Jacobi integral :" << -2*H(q[0]) << endl;
        cout << "Lyapunv orbit bound for midpoints:" << endl;
		for(int i=0;i<q.size();i++) cout << i << " & "<< q[i][0].mid().leftBound() << " & " << q[i][1].mid().leftBound() << " & " << q[i][2].mid().leftBound() << " & " << q[i][3].mid().leftBound() << " \\\\" <<  endl;
		cout << "Lyapunv enclosure size: " << max_norm_diam(q) << endl;
		cout << "time between points " << t << endl;
		cout << "Lyapunov orbit period: " << LyapPeriod << endl << endl;
	
		// //////////////////////////////////////////////////////////////
		// 2. Computation of a bound on the unstable manifold at q[0] //
		// //////////////////////////////////////////////////////////////
		vector<IMatrix> Au=matricesFromFile();
		Au[Au.size()-1]=Au[0]; // making sure that we start and return to the same local coordinates.
		
		interval range=3*pow(10.0,-8.0);
		interval L=5.0*pow(10.0,-6.0);
		
		// The bound on the unstable manifold is of the form:
		//     Wu(x) \in q[0] + x*A[0]*v     for all x \in range*(-1,1)
		//    dWu(x) \in A[0]*v              for all x \in range*(-1,1)
		int d=5;
		interval m, mbar;
		vector<IVector> Cone;
		// Below line validates the enclosure of the unstable manifold:
		if(validateWuEnclosure(q,t,Au,L,range,Phi,d,m,mbar,P,Cone)==0){ cout << "unstable manifold has not been validated. Aborting program!" << endl; abort(); }
		cout << "A0 = " << Au[0] << endl;
		cout << "L = " << L << endl;
		cout << "m = " << m << endl;
		cout << "mbar = " << mbar << endl;
		int nOfLyapPts=q.size();
		cout << "n = " << nOfLyapPts << endl;
		interval lambda=power(mbar,-nOfLyapPts);
		cout << "lambda = " << power(mbar,-nOfLyapPts) << endl;
		cout << "1/lambda = " << power(mbar,nOfLyapPts) << endl << endl; 
		
		// //////////////////////////////////////////////////////////////////////////
		// 3. Computation of a bound on the fibers at q[0] in extended phase space //
		// //////////////////////////////////////////////////////////////////////////
		interval M_=3;
		cout << "Validating the bounds on the fibers in the extended phases space. The considered parameters are: " << endl;
		cout << "L = " << L << endl;
		cout << "M = " << M_ << endl;
		if(validateFiberInExtendedPhaseSpace(q,t,Au,L,M_,range,Phi_,P_,d)==0)
		{
			cout << "Proof failed. Validation of the fiber in extended phase space did not go through. Aborting program." << endl;
			return 0;
		}
		cout << endl;
		
		// //////////////////////////////////////////////
		// 4. Bound on the stable fibers from symmetry //
		// //////////////////////////////////////////////
		vector<IMatrix> As=Au;
		vector<IVector> ConeS=Cone;
		validateWsEnclosure(As,ConeS);
        
		// ///////////////////////////////////////////////////////
		// 5. checking twist conditions for persistence of NHIM //
		// ///////////////////////////////////////////////////////
		if(validatePersistenceOfNHIM(t,q,Phi,F,H)==0)
		{
			cout << "twist condition for persistence of NHIM failed. Aborting program. Proof failed." << endl;
			return 0;
		}
		cout << endl;
		
		// ///////////////////////////////////////
        // 6. Computation of Homoclinic orbit   //
		// ///////////////////////////////////////
		int n=20;

		IVector v0(4);
		v0[0]=1.0; 
		interval h1=-0.000000005;
		interval s1;
        vector<IVector> p1=pointsOnHomoclinic(q[0],Au[0],L,range,Phi,F,n,s1,h1);
		if(establishTransversality(p1,s1,Au[0],L,Phi,P)==0){ cout << "Unable to prove that Wu and Ws intersect transversally. Aborting program. Proof failed. " << endl; abort(); }
		p1=pointsOnFullHomoclinic(p1,Phi,s1);
		cout << "bounds on the homoclinic: " << endl;
		for(int i=0;i<p1.size();i++)
		{ 
			cout << i << " & " 
			<< p1[i][0].mid().leftBound() << " & "
			<< p1[i][1].mid().leftBound() << " & "
			<< p1[i][2].mid().leftBound() << " & "
			<< p1[i][3].mid().leftBound() << " \\\\ "<< endl;
		}
		interval timeAlongHomoclinic=p1.size()*s1;
		cout << "time between points: " << s1 << endl;
		cout << "time needed to pass along the homoclinic: " << timeAlongHomoclinic << endl;
		cout << "Homoclinic enclosure accuracy: " << max_norm_diam(p1) << endl << endl;
		cout << "sigma(I,lambda) = (I, lambda + " <<  scatteringMap(interval(0),range,M_,LyapPeriod,timeAlongHomoclinic) << ")"<< endl;
		
		// plotHomoclinic(p1,s1); // this was used to produce the plot from the paper. It is not part of the proof.
		
		// //////////////////////////////////
		// 7. Computation of the Lg bound. //
		// //////////////////////////////////
		cout << "computation of the Lg bound. This will take a while. " << endl;
        cout << "computation for points along Wu (countdown below): " << endl;
		interval Lg=LgBound(q,Au,Cone,range,t,mbar,PhieC2,PeC2,He);	
		cout << "Lg = "<< Lg << endl << endl;						
        cout << "computation for points along Ws (countdown below): " << endl;
		Lg=intervalHull(Lg,LgBound(q,As,ConeS,range,t,interval(1.0)/m,PhieC2,PeC2,He)).right();
		cout << "Lg = "<< Lg << endl << endl;
		
		// plotEnergyChange(p1,s1,Phie,Pe,He);  // this was used to produce the plot from the paper. It is not part of the proof.

		As=to6dim(As);
		ConeS=to6dim(ConeS);
		
		interval dH(0);
		interval Sd=0.65+interval(-0.125,0.125);
		interval Su=Sd+interval::pi();
		
		IMaxNorm Norm;
		IVector B(4);
		B[0]=interval(-1,1);
		for(int i=1;i<4;i++) B[i]=B[0]*L;
		interval C=range;
		cout << "C = " << C << endl;
		cout << "C*Lg = " << C*Lg << endl;
		cout << "Sd = " << Sd << endl;
		cout << "Su = " << Su << endl;
		int divisions=25;
        cout << "validating strip Sd. We subdivide Sd into " << divisions << " fragments for our validation." << endl;		
		
		// ////////////////////////////////////////////////
		// 8. Validation of energy changes from Sd to Sd //
		// ////////////////////////////////////////////////
		for(int i=0;i<divisions;i++)
		{
			interval theta=part(Sd,divisions,i);
			checkStripTransition(theta,LyapPeriod,Su);
			cout << i+1 << "   angle=" << theta;
			int m_iterates=find_m_iterates(theta,range,M_,LyapPeriod,timeAlongHomoclinic,Sd);
			cout << "   m=" << m_iterates;
			interval R=range;
			// first five iterates of the map f:
			dH=gI(p1,theta,s1,Phie,Pe,He);
		
			// we compute the sum of \pi_I g for remaining iterates of the map:
			for(int j=0;j<m_iterates-5;j++) dH = dH + gI(q,As,ConeS,R,m,theta,t,Phie,Pe,He); 
			if(not (dH+(interval(1.0)+lambda)*Lg*C/(interval(1.0)-lambda)<interval(0))) 
			{
				cout << "problem with energy reduction along Sd. Proof failed. Aborting program." << endl;
				return 0;
			}
			cout << "   energy change=" << dH << endl; 
		}
		
		// ////////////////////////////////////////////////
		// 9. Validation of energy changes from Su to Su //
		// ////////////////////////////////////////////////
        cout << "validating strip Su. We subdivide Su into " << divisions << " fragments for our validation." << endl;		
		for(int i=0;i<divisions;i++)
		{
			interval theta=part(Su,divisions,i);
			checkStripTransition(theta,LyapPeriod,Sd);
			cout << i+1 << "   angle=" << theta;
			int m_iterates=find_m_iterates(theta,range,M_,LyapPeriod,timeAlongHomoclinic,Su);
			cout << "   m=" << m_iterates;
			interval R=range;
			// the sum of \pi_I g(f^i(x)) for the first five iterates of the map f:
			dH=gI(p1,theta,s1,Phie,Pe,He);
		
			// we compute the sum of \pi_I g(f^i(x)) for remaining iterates of the map f:
			for(int j=0;j<m_iterates-5;j++) dH = dH + gI(q,As,ConeS,R,m,theta,t,Phie,Pe,He); 
			if(not (dH-(interval(1.0)+lambda)*Lg*C/(interval(1.0)-lambda)>interval(0))) 
			{
				cout << "problem with energy increment along Su. Proof failed. Aborting program." << endl;
				return 0;
			}
			cout << "   energy change=" << dH << endl; 
		}
	}
  	catch(exception& e)
    {
      	cout << "\n\nException caught: " << e.what() << endl;
    }
	after=time(NULL);
	cout << "The proof ended successfully." << endl;
    cout << "time: " << difftime(after,before) << " s " << endl;
    return 1; 
}



