#include "persistenceOfNHIM.h"

IVector twistCoefficients(interval tau, vector<IVector> q, ITimeMap &Phi, IMap &F)
{
	int n=q.size()/2-1;
	IMatrix DPhi(4,4);
	for(int i=0;i<4;i++) DPhi[i][i]=interval(1);
	
	for(int i=0;i<=n;i++)
	{
		IMatrix dPhiTau(4,4);
		C1Rect2Set Q(q[i]);
		Phi(tau,Q,dPhiTau); // this computes dPhiTau
		DPhi=dPhiTau*DPhi;
	}
	IVector e0(4),e3(4);
	e0[0]=interval(1);
	e3[3]=interval(1);
	
	IVector dgdX(2);
	dgdX[0]=(DPhi*e0)[1]; // coordinate Y
	dgdX[1]=(DPhi*e0)[2]; // coordinate PX
	
	IVector dgds(2);
	dgds[0]=(DPhi*e3)[1]; // coordinate Y
	dgds[1]=(DPhi*e3)[2]; // coordinate PX
	
	IVector dgdtau(2);
	dgdtau[0]=(n+1)*F(q[n+1])[1];
	dgdtau[1]=(n+1)*F(q[n+1])[2];
	
	IMatrix dg(2,2);
	dg[0][0]=dgds[0];  dg[0][1]=dgdtau[0];
	dg[1][0]=dgds[1];  dg[1][1]=dgdtau[1];
	
	return -gauss(dg,dgdX);
}

bool validatePersistenceOfNHIM(interval tau, vector<IVector> q, ITimeMap &Phi, IMap &F, IMap &H)
{
	IVector v=twistCoefficients(tau,q,Phi,F);
	int n=q.size()/2-1;
	interval dTdX=(2*n+2)*v[1];
	IVector dx0dX(4);
	dx0dX[0]=1;
	dx0dX[3]=v[0];
	cout << "dx0/dX = " << dx0dX << endl;
	cout << "dtau/dX = " << v[1] << endl;
	cout << "dT/dX = " << dTdX << endl;
	cout << "d/dX H(x0(X)) = " << (H[q[0]]*dx0dX)[0] << endl; 
	if(not (dTdX<0.0)) return 0;
	if(not ((H[q[0]]*dx0dX)[0]<0.0)) return 0;
	return 1;
}