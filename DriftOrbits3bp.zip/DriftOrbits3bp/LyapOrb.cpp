#include "LyapOrb.h"
#include "constants.h"
#include "utils.h"


// this function computes a single point on a Lyapunov orbit of the form 
//  (x,0,0,py)
// this is then used for the function LyapPoint(x), below, as a starting point for a continuation method.
DVector LyapPoint1()
{
    DVector x(4); 
    x[0]=-0.95;
    x[3]=-0.8413472441;
    return x;
}

// this function computes a single point on a Lyapunov orbit of the form 
//  (x0,0,0,py(x0))
DVector LyapPoint(double x0)
{
     DMap F = "par:mu;var:X,Y,PX,PY;fun:PX+Y,PY-X,PY-X+(X-(1-mu)*(X-mu)*((X-mu)^2+Y^2)^(-1.5)-mu*(X-mu+1)*((X-mu+1)^2+Y^2)^(-1.5)),-PX-Y+(Y-(1-mu)*Y*((X-mu)^2+Y^2)^(-1.5)-mu*Y*((X-mu+1)^2+Y^2)^(-1.5));";
     F.setParameter("mu",mu);
     DCoordinateSection section(4,1);
     DOdeSolver solver(F,TAYLOR_ORDER);
     DPoincareMap P(solver,section);
       
     DVector x=LyapPoint1();
    
     int N=100;
     double dx=(x0-x[0])/N;
       
     for(int i=0;i<N;i++)
     {
           x[0]=x[0]+dx;
           DMatrix DP(4,4);
           DMatrix DPhi(4,4);
           DVector y(4);
           for(int i=0;i<10;i++) 
           {
               y = P(x,DPhi);  // f(x)=y[2]
               DP = P.computeDP(y,DPhi);  // Df(x) = DP[2][3]
               // x' = x - f(x)/Df(x)
               x[3] = x[3] - y[2]/DP[2][3];
           }
     }
     return x;
}

double timeToSection(DVector q)
{
    int sect=1;
    DMap F = "par:mu;var:X,Y,PX,PY,t;fun:PX+Y,PY-X,PY-X+(X-(1-mu)*(X-mu)*((X-mu)^2+Y^2)^(-1.5)-mu*(X-mu+1)*((X-mu+1)^2+Y^2)^(-1.5)),-PX-Y+(Y-(1-mu)*Y*((X-mu)^2+Y^2)^(-1.5)-mu*Y*((X-mu+1)^2+Y^2)^(-1.5)),1.0;";
    F.setParameter("mu",mu);
    DOdeSolver solver(F,TAYLOR_ORDER);
    DCoordinateSection section(5,sect);
    DTimeMap Phi(solver);
    DPoincareMap P(solver,section);
    
    DVector p(5);
    for(int i=0;i<4;i++) p[i]=q[i];
    p=P(p);

    return p[4];
}

