#include "MelnikovComputation.h"
#include "utils.h"
#include "constants.h"
using namespace capd::vectalg;


int find_m_iterates(interval theta,interval range,interval M,interval LyapPeriod,interval homoclinicTime,interval strip)
{
	interval sigma=scatteringMap(theta,range,M,LyapPeriod,homoclinicTime);
	sigma=mod2Pi(sigma);
	if(subsetInterior(sigma,strip)) return 0;
	for(int m=1;m<100;m++)
	{
		sigma=mod2Pi(sigma+LyapPeriod);
		if(subsetInterior(sigma,strip)) return m;
	}
	cout << "Problem with computing m(z). Aborting program. Proof failed. " << endl;
	abort();
	return -1;
}

void checkStripTransition(interval theta,interval LyapPeriod,interval strip)
{
	for(int i=0;i<100;i++)
	{
		theta=mod2Pi(theta+LyapPeriod);
		if(subsetInterior(theta,strip)) return;
	}
	cout << "Problem with transition to strip. Aborting program. Proof failed." << endl;
	abort();
}

//////////////////

vector<IVector> pointsInExtendedSpace(vector<IVector> p,interval theta,interval t)
{
	int n=p.size();
	for(int i=0;i<n;i++)
	{
		IVector q(6);
		for(int j=0;j<4;j++) q[j]=p[i][j];
		q[4]=theta+i*t; // time coordinate
		p[i]=q;
	}
	return p;
}

////////////////////////////////////

IMatrix Hessian(const IJet &JH)
{
	IMatrix Hess(6,6);
	for(int i=0;i<5;i++)
		for(int j=0;j<5;j++)
			Hess[i][j]=JH(0,i,j);

	for(int i=0;i<5;i++) Hess[i][i]=2.0*Hess[i][i];
	return Hess;
}

IMatrix dH(const IJet &JH)
{
	IMatrix DH(1,6);
	for(int i=0;i<5;i++)
		DH=JH(0,i);
	return DH;
}

IMatrix dEps(const CnRect2Set &Jf)
{
	IMatrix df(6,1);
	for(int i=0;i<5;i++) df[i][0]=Jf.currentSet()(i,5);
	return df;
}
IMatrix dEps(const IJet &Jf)
{
	IMatrix df(6,1);
	for(int i=0;i<5;i++) df[i][0]=Jf(i,5);
	return df;
}

IMatrix dx(const CnRect2Set &Jf)
{
	IMatrix df(6,6);
	for(int i=0;i<5;i++)
		for(int j=0;j<5;j++)
			df[i][j]=Jf.currentSet()(i,j);;
	return df;
}
IMatrix dx(const IJet &Jf)
{
	IMatrix df(6,6);
	for(int i=0;i<5;i++)
		for(int j=0;j<5;j++)
			df[i][j]=Jf(i,j);
	return df;
}

IMatrix dxdEps(const CnRect2Set &Jf)
{
	IMatrix df(6,6);
	for(int i=0;i<5;i++)
		for(int j=0;j<5;j++)
			df[i][j]=Jf.currentSet()(i,j,5);
	return df;
}
IMatrix dxdEps(const IJet &Jf)
{
	IMatrix df(6,6);
	for(int i=0;i<5;i++)
		for(int j=0;j<5;j++)
			df[i][j]=Jf(i,j,5);
	return df;
}

/////////////////////////////////////

interval LgBound(vector<IVector> q, vector<IMatrix> A, vector<IVector> cone, const interval &range, const interval &t,
					ICnTimeMap &Phi,ICnPoincareMap &P,IMap &H, const interval &theta,const interval &mbar)
{
	cone=to6dim(cone);
	A=to6dim(A);
	
	IVector B(6);
	
	q=pointsInExtendedSpace(q,theta,t);
	int n=q.size();
	
	interval Lg(0.0);
    interval Lf1(1.0);
	
	IMatrix dfdEps, D2H, Df, DH, dfdxdEps;
	
	IMaxNorm Norm;
	for(int i=0;i<n-1;i++)
	{
        IJet JH(6,2);
		B=interval(-1,1)*range*cone[i];
		CnRect2Set X(q[i],A[i],B,2);
		IVector Y=Phi(t,X);
        H(Y,JH);
        
		dfdEps=dEps(X);
		D2H=Hessian(JH);
		Df=dx(X);
		DH=dH(JH);
		dfdxdEps=dxdEps(X);
		
		IMatrix v=(transpose(dfdEps)*D2H*Df+DH*dfdxdEps)*A[i];
		Lg=Norm(v)*Lf1+Lg;
        
		Lf1=mbar*Lf1;
	}
	
	B=interval(-1,1)*range*cone[n-1];
	CnRect2Set X(q[n-1],A[n-1],B,2);
	IJet Jf(6,2),JH(6,2);
	IVector Y=P(X,Jf);
    Jf=P.computeDP(Jf);
    H(Y,JH);
	
	dfdEps=dEps(Jf);
	D2H=Hessian(JH);
	Df=dx(Jf);
	DH=dH(JH);
	dfdxdEps=dxdEps(Jf);
	
	IMatrix v=(transpose(dfdEps)*D2H*Df+DH*dfdxdEps)*A[n-1];
	Lg=Norm(v)*Lf1+Lg;
    return Lg;
}

interval LgBound(const vector<IVector> &q,const vector<IMatrix> &A,const vector<IVector> &cone, const interval &range, const interval &t, const interval &mbar,
					ICnTimeMap &Phi,ICnPoincareMap &P,IMap &H)
{
	int N=10;
	interval theta,Lg(0);
	for(int i=0;i<N;i++)
	{
		theta=part(intervalHull(interval(0),interval(2)*interval::pi()),N,i);
        Lg=intervalHull(Lg,LgBound(q,A,cone,range,t,Phi,P,H,theta,mbar)).right();
		cout << N-i << " " ;
        cout.flush();
	}
    cout << endl;
	return Lg;
}

IVector d_de(const IMatrix &D)
{
	IVector de(6);
	for(int i=0;i<6;i++) de[i]=D[i][5];
	return de;
}

interval gI(vector<IVector> p,interval &theta,interval t,ITimeMap &Phi,IPoincareMap &P,IMap &H)
{
	//  d/de H(Phi(t,x)) = DH(Phi(t,x))* d/de Phi(t,x)
	interval dH(0.0);
	int n=p.size();
	p=pointsInExtendedSpace(p,theta,t);
	IMatrix DPhi(6,6);
	for(int i=0;i<n-1;i++)
	{
		C1Rect2Set X(p[i]);
		IVector y=Phi(t,X,DPhi);
		dH=dH+(H[y]*d_de(DPhi))[0];
		theta=theta+t;
	}
	interval timeToSection;
	C1Rect2Set X(p[n-1]);
	IVector y=P(X,DPhi,timeToSection);
	theta=theta+timeToSection;
	IMatrix DP=P.computeDP(y,DPhi);
	dH=dH+(H[y]*d_de(DP))[0];
	return dH;
}

interval gI(vector<IVector> p,vector<IMatrix> A, vector<IVector> Cone,interval &Domain,interval m,interval &theta,interval t,ITimeMap &Phi,IPoincareMap &P,IMap &H)
{
	interval dH(0.0);
	int n=p.size();
	p=pointsInExtendedSpace(p,theta,t);
	IMatrix DPhi(6,6);
	
	for(int i=0;i<n-1;i++)
	{
		IVector B=interval(-1,1)*Domain*Cone[i];
		C1Rect2Set X(p[i],A[i],B);
		IVector y=Phi(t,X,DPhi);
		dH=dH+(H[y]*d_de(DPhi))[0];
		theta=theta+t;
		Domain=Domain/m;
	}
	
	interval timeToSection;
	IVector B=interval(-1,1)*Domain*Cone[n-1];
	C1Rect2Set X(p[n-1],A[n-1],B);
	IVector y=P(X,DPhi,timeToSection);
	theta=theta+timeToSection;
	IMatrix DP=P.computeDP(y,DPhi);
	dH=dH+(H[y]*d_de(DP))[0];
	Domain=Domain/m;
	return dH;
}




