#include "DLyapParallelShooting.h"
#include "OperationsForShooting.h"
#include "time.h"
#include "LyapOrb.h"
#include "constants.h"


////////////////////////////////////
// The function for our parallel shooting is
// F(q) = F(q0,w1,w2,...,wn,t)
//      = (Phi(t,(x,0,0,q0))-w1,
//         Phi(t,w1)-w2,
//         Phi(t,wn-1)-wn,
//         pi_y  o Phi(t,wn),
//         pi_px o Phi(t,wn))
//
// The function takes a vector q=(q0,w1,w2,...,wn,t) and computes p=F(q);
DVector Function(double x,DVector q, DTimeMap &Phi, int n)
{
	DVector p(2+4*n), w(4);
    double t=q[1+4*n];

    w[0]=x;
    w[1]=0.0;
    w[2]=0.0;
    w[3]=q[0];
    
    Insert(p,Phi(t,w)-PullOut(q,1),1); // phi(T,(x,0,0,q0)) - (q1,q2,q3,q4)

    for(int j=1;j<n;j++)
    {
        w=PullOut(q,j);
        Insert(p,Phi(t,w)-PullOut(q,j+1),j+1);
    }
    w=PullOut(q,n);
    w=Phi(t,w);
    p[4*n]=w[1]; // projection on coordinate y
    p[4*n+1]=w[2]; // projection on coordinate px
    return p;
}
// This function computes the derivative of above function:
DMatrix Derivative(double x,DVector q, DTimeMap &Phi, DMap &F, int n)
{
	DMatrix DF(2+4*n,2+4*n), DPhi(4,4);
    DVector w(4);
    double t=q[1+4*n];
    
    w[0]=x;
    w[1]=0.0;
    w[2]=0.0;
    w[3]=q[0];
    Phi(t,w,DPhi);
    PutFirst(Column(DPhi,3),DF);
    InsertLastColumn(F(w),DF,0);
    
    PutId(DF,n); // we put -Id
    
    for(int j=1;j<n;j++)
    {
        w=PullOut(q,j);
        w=Phi(t,w,DPhi);
        InsertLastColumn(F(w),DF,j);
        PutIn(DPhi,DF,j);
    }
    
    w=PullOut(q,n);
    w=Phi(t,w,DPhi);
                 
    PutLast(Row(DPhi,1),DF,n);
    PutSecondLast(Row(DPhi,2),DF,n);

    DF[4*n][1+4*n]=F(w)[1];
    DF[1+4*n][1+4*n]=F(w)[2];
        
    return DF;
}

DVector LyapParallelShooting(double xL,int n, DMatrix &C, DMap &F, DTimeMap &Phi)
{   
	DVector q(2+4*n), w(4), x(4);
    w=LyapPoint(xL);
	
	q[0]=w[3];
    
	double t=timeToSection(w)/(n+1.0);
    
	q[4*n+1]=t;
    
	for(int l=1;l<n+1;l++)
	{
		w=Phi(t,w);
		int j=0;
		for(int i=1+4*(l-1);i<1+4*l;i++)
		{
			q[i]=w[j];
			j++;
		}
	}
    
	for(int i=0;i<20;i++)
	{ 
		q=q-gauss(Derivative(xL,q,Phi,F,n),Function(xL,q,Phi,n)); // Newton's method
	}
    C=gaussInverseMatrix(Derivative(xL,q,Phi,F,n)); // matrix made for Krawczyk's method
    
	return q;
}

inline double timeBetweenPointsOnLyapOtbit(DVector p){return p[(int)p.dimension()-1];}

DVector S(DVector x)
{
	x[1]=-x[1];
	x[2]=-x[2];
	return x;
}
vector<DVector> pointsOnLyapOtbit(double x,DVector p,DTimeMap &Phi,double &t)
{
	t=timeBetweenPointsOnLyapOtbit(p);
	int n=(p.dimension()-2)/4;
	vector<DVector> w(2*n+2);
	w[0]=DVector(4);
	w[0][0]=x;
	w[0][3]=p[0];
	
	for(int i=1;i<=n;i++) w[i]=PullOut(p,i);
	DVector dummy=w[n];
	w[n+1]=Phi(t,dummy);
	
	for(int i=1;i<=n;i++) w[n+1+i]=S(w[n+1-i]);
	return w;
}
