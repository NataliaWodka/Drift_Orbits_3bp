#ifndef ILyapParallelShooting_h
#define ILyapParallelShooting_h
#include "capd/capdlib.h"
using namespace capd;
using namespace std;

IVector S(IVector x);

///////////////////////////////////////
// FUNCTION OF MAIN INTEREST
// This computes the sequence of points around the Lyapunov orbit and validates them:
vector<IVector> pointsOnLyapOrb(interval x,ITimeMap &Phi,IMap &F,int n,interval &t);

#endif