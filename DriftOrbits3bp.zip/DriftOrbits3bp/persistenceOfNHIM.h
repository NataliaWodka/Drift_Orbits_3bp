#ifndef persistenceOfNHIM_h
#define persistenceOfNHIM_h

#include <iostream>
#include "capd/capdlib.h"
using namespace capd;
using namespace std;
using namespace capd::matrixAlgorithms;

bool validatePersistenceOfNHIM(interval tau, vector<IVector> q, ITimeMap &Phi, IMap &F, IMap &H);

#endif