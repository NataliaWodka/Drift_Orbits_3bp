#ifndef DHomParallelShooting_h
#define DHomParallelShooting_h

#include <iostream>
#include <time.h>
#include "capd/capdlib.h"
using namespace capd;
using namespace std;
using namespace capd::matrixAlgorithms;

DVector HomoclinicParallelShooting(DVector p0,DMatrix A,int n, double h, DMatrix &C,DMap &F,DTimeMap &Phi);

// This function recovers the sequence of 2*n+1 points around they homoclinic orbit:
vector<DVector> homoclinic(DVector p,DVector p0,DMatrix A,DTimeMap &Phi,double &t);

#endif