#ifndef IHomParallelShooting_h
#define IHomParallelShooting_h

#include <iostream>
#include <time.h>
#include "capd/capdlib.h"
using namespace capd;
using namespace std;

///////////////////////////////////////
// FUNCTION OF MAIN INTEREST
// This computes the sequence of points along a homoclinic to a Lyapunov orbit and validates them.
// The initial point of the homoclinic should be close to our initial guess, which is:
//    p0+h*A*(1,0,0,0)
// The guess is modified using the (non rigorous) Newton method, and ten validated using the Krawczyk method.
// This function computes half of the points along the homoclinic, up to the S-symmetric intersection point on {Y=0}.
vector<IVector> pointsOnHomoclinic(IVector p0,IMatrix A,interval L,interval range,ITimeMap &Phi,IMap &F,int n,interval &t,interval &h);

// This function takes the sequence of points computed by pointsOnHomoclinic() and completes the remaining second half 
// of the homoclinic orbits from the S-symmetry.
vector<IVector> pointsOnFullHomoclinic(vector<IVector> p,ITimeMap &Phi,interval t);

//////////////////////////////////////
// Function: establishTransversality()
// 
// The function pointsOnHomoclinic() establishes a sequence of points along a homoclinic orbit to a Lyapunov orbit.
// This homoclinic orbit lies along an intersection of the stable and unstable manifolds. 
// The function establishTransversality() validates that this intersection is transversal.
// This is done by propagating the cone, which provides the bound on the derivative of the unstable fiber,
// upt to the point of intersection of the manifolds on section {Y=0}. Thus propagated cone provides the bound one the 
// tangent vectors to the one dimensional curves, which result from intersectiong the unstable manifold of a
// Lyapunov orbit with section {Y=0}. From the tangent vectors and S-symmetry follows transversality, as described in the paper.
bool establishTransversality(const vector<IVector> &q,interval s,IMatrix A,interval L,ITimeMap &Phi,IPoincareMap &P);

#endif