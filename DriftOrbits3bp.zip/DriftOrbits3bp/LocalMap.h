#ifndef LocalMap_h
#define LocalMap_h

#include <iostream>
#include <time.h>
#include "capd/capdlib.h"
#include "utils.h"
using namespace capd;
using namespace std;
using namespace capd::alglib;
using namespace capd::matrixAlgorithms;

//////////////////////
// class DLocalMap
//
// 
class DLocalMap
{
private:
	DMatrix A,B;
	DVector a,b;
	DTimeMap *Phi;
	double T;	
public:
	// constructor
	DLocalMap(DVector a, DVector b, DMatrix A, DMatrix B, DTimeMap &Phi, double T);
	
	// constructor
	DLocalMap(){}

	DVector image(const DVector &x) const;
	DVector image(const DVector &x, DMatrix &Df) const;
	DVector operator()(const DVector &x) const {return image(x);}
	DVector operator()(const DVector &x, DMatrix &Df) const {return image(x,Df);}
	DMatrix derivative(const DVector &x) const;
	DMatrix operator[](const DVector &x) const {return derivative(x);}
};

vector<DLocalMap> LocalMap(const vector<DVector> &x, const vector<DMatrix> &A, DTimeMap &Phi, double T);
// The objective of this function is to create a vector of k DLocalMap which is full set of maps between all points on the Lyapunov orbit.


// // // // rigorous // // // //

IVector PropagateCone(const IMatrix &DF,const IVector &C);

class ILocalMap
{
private:
	IMatrix A,B;
	IVector a,b;
	ITimeMap *Phi;
	IPoincareMap *P;
	interval T;	
public:
	// constructor: 
	ILocalMap(IVector a, IVector b, IMatrix A, IMatrix B, ITimeMap &Phi, interval T);
	ILocalMap(IVector a, IVector b, IMatrix A, IMatrix B, IPoincareMap &P);
	
	// constructor
	ILocalMap(){}

	IVector image(const IVector &x) const;
	IVector image(const IVector &x, IMatrix &Df) const;
	IVector operator()(const IVector &x) const {return image(x);}
	IVector operator()(const IVector &x, IMatrix &Df) const {return image(x,Df);}
	IMatrix derivative(const IVector &x) const;
	IMatrix operator[](const IVector &x) const {return derivative(x);}
	IVector propagateCone(const IVector &x, const IVector &Cone) const {return PropagateCone(derivative(x),Cone);}
	IVector propagateCone(const IVector &x, const IVector &Cone, int n) const;
};

vector<ILocalMap> LocalMap(const vector<IVector> &x, const vector<IMatrix> &A, ITimeMap &Phi, interval T);
vector<ILocalMap> LocalMap(const vector<IVector> &x, const vector<IMatrix> &A, ITimeMap &Phi, interval T,IPoincareMap &P);

#endif
