#ifndef utils_h
#define utils_h
#include "capd/capdlib.h"
using namespace capd;
using namespace std;

IVector toInterval(const DVector &x);
IMatrix toInterval(const DMatrix &A);
inline double toDouble(const interval &x){return x.mid().leftBound();}
inline interval part(interval x, int n, int i) {return x.left()+i*(x.right()-x.left())/n+(x-x.left())/n;}

interval mod2Pi(const interval &x);

DMatrix toDouble(const IMatrix &A);
DVector toDouble(const IVector &x);

vector<DVector> toDouble(const vector<IVector> &x);
vector<IMatrix> toInterval(const vector<DMatrix> &A);

IVector to5dim(const IVector &x);
IMatrix to5dim(const IMatrix &A);

vector<IVector> to5dim(const vector<IVector> &x);
vector<IMatrix> to5dim(const vector<IMatrix> &A);

IVector to6dim(const IVector &x);
IMatrix to6dim(const IMatrix &A);

vector<IVector> to6dim(const vector<IVector> &x);
vector<IMatrix> to6dim(const vector<IMatrix> &A);

interval max_norm_diam(IVector x);
interval max_norm_diam(vector<IVector> x);

vector<IMatrix> matricesFromFile();

#endif
