#include "utils.h"

IVector toInterval(const DVector &x)
{
    int n=x.dimension();
    IVector y(n);
    for(int i=0;i<n;i++) y[i]=x[i];
    return y;
}

IMatrix toInterval(const DMatrix &A)
{
    int k=A.numberOfColumns();
    int r=A.numberOfRows();
    IMatrix B(r,k);
    for(int i=0;i<r;i++)
        for(int j=0;j<k;j++) B[i][j]=A[i][j];
    return B;
}

DVector toDouble(const IVector &x)
{
    int n=x.dimension();
    DVector y(n);
    for(int i=0;i<n;i++) y[i]=(x[i].mid()).leftBound();
    return y;
}


vector<DVector> toDouble(const vector<IVector> &x)
{
	int n=x.size();
	vector<DVector> y(n);
	for(int i=0;i<n;i++) y[i]=toDouble(x[i]);
	return y;
}

vector<IMatrix> toInterval(const vector<DMatrix> &A)
{
    int k=A.size();
    vector<IMatrix> B(k);
    for(int i=0;i<k;i++) B[i]=toInterval(A[i]);
    return B;
}

DMatrix toDouble(const IMatrix &A)
{
    int k=A.numberOfColumns();
    int r=A.numberOfRows();
    DMatrix B(r,k);
    for(int i=0;i<r;i++)
        for(int j=0;j<k;j++) B[i][j]=A[i][j].mid().leftBound();
    return B;
}

interval mod2Pi(const interval &x)
{
	interval twoPi=2*interval::pi();
	if(subsetInterior(x,twoPi*interval(-1.0,1.0))){ return x;} else
	{
		if(x.right()>twoPi) return mod2Pi(x-twoPi);
		if(x.left()<-twoPi) return mod2Pi(x+twoPi);
	}
	return interval(0); // added only to get rid of warnings during compilation
}

IVector to5dim(const IVector &x)
{
	IVector y(5);
	for(int i=0;i<4;i++) y[i]=x[i];
	return y;
}
IMatrix to5dim(const IMatrix &A)
{
	IMatrix B(5,5);
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			B[i][j]=A[i][j];
	B[4][4]=1;
	return B;
}

vector<IVector> to5dim(const vector<IVector> &x)
{
	int n=x.size();
	vector<IVector> y(n);
	for(int i=0;i<n;i++) y[i]=to5dim(x[i]);
	return y;
}

vector<IMatrix> to5dim(const vector<IMatrix> &A)
{
	int n=A.size();
	vector<IMatrix> B(n);
	for(int i=0;i<n;i++) B[i]=to5dim(A[i]);
	return B;
}

IVector to6dim(const IVector &x)
{
	IVector y(6);
	for(int i=0;i<4;i++) y[i]=x[i];
	return y;
}
IMatrix to6dim(const IMatrix &A)
{
	IMatrix B(6,6);
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			B[i][j]=A[i][j];
	B[4][4]=1;
	B[5][5]=1;
	return B;
}

vector<IVector> to6dim(const vector<IVector> &x)
{
	int n=x.size();
	vector<IVector> y(n);
	for(int i=0;i<n;i++) y[i]=to6dim(x[i]);
	return y;
}

vector<IMatrix> to6dim(const vector<IMatrix> &A)
{
	int n=A.size();
	vector<IMatrix> B(n);
	for(int i=0;i<n;i++) B[i]=to6dim(A[i]);
	return B;
}

interval max_norm_diam(IVector x)
{
	int n=x.dimension();
	interval r=0.0;
	for(int i=0;i<n;i++)
	{
		interval b=(x[i]-x[i].mid()).right();
		if(r<b) r=b;
	}
	return r;
}

interval max_norm_diam(vector<IVector> x)
{
	int n=x.size();
	interval r=0.0;
	for(int i=0;i<n;i++)
	{
		interval b=max_norm_diam(x[i]);
		if(r<b) r=b;
	}
	return r;
}

// This matric imports the precomputed linear changes used for our local coordinates. 
// We note that for our computer assisted proof we can use any local coordinates we want. 
// These do not need to be computed. They can be assumed. Provided that we can check our conditions in the given local coordinates
// we are sure that the computer assisted proof performs correctly.
vector<IMatrix> matricesFromFile()
{
	ifstream file("data/matrices.txt");
	int n=31;
	vector<IMatrix> A(n);
	
	double a;
	for(int i=0;i<n;i++)
	{
		A[i]=IMatrix(4,4);
		for(int k=0;k<4;k++)
		{
			for(int j=0;j<4;j++)
			{
				file >> a;
				A[i][k][j]=a; 
			}
		}
	}
	file.close();
	return A;
}
